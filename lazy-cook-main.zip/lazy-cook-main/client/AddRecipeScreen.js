import React, { useState } from "react";
import {
  Button,
  StyleSheet,
  TouchableOpacity,
  View,
  Text,
  FlatList,
  TextInput,
  ScrollView,
  LogBox,
  Image,
} from "react-native";

import colors from "./config/colors";
import Screen from "./components/Screen";
import AddCameraModal from "./components/AddCameraModal";
import AuthContext from "./auth/context";
import authStorage from "./auth/storage";

import { Camera } from "expo-camera";

import { MaterialCommunityIcons } from "@expo/vector-icons";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import { color } from "react-native-reanimated";

class AddRecipeScreen extends React.Component {
  static contextType = AuthContext;
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      token: "",
      vegetarian: false,
      vegan: false,
      glutenFree: false,
      lactoseIntolerance: false,
      title: "",
      ingredients: [""],
      quantities: [""],
      instructions: "",
      image: undefined,
      cameraOn: false,
      disable: false,
    };
    this.componentDidMount = this.componentDidMount.bind(this);
    this.handleAdd = this.handleAdd.bind(this);
    this.setCameraOn = this.setCameraOn.bind(this);
    this.pictureFromCamera = this.pictureFromCamera.bind(this);
    this.handleInputButton = this.handleInputButton.bind(this);
  }

  async componentDidMount() {
    const { userName, userToken } = this.context;
    this.setState({
      username: userName,
      token: userToken,
    });
    LogBox.ignoreLogs(["VirtualizedLists should never be nested"]);
  }

  async handleAdd() {
    this.setState({ disable: true })
    let inputIngredients = [];
    for (let i = 0; i < this.state.ingredients.length; i++) {
      let ingred = this.state.ingredients[i].replace(/ /g, '_');
      let qty = this.state.quantities[i];
      if (ingred === "") {
        continue;
      }
      if (qty === "") {
        qty = "1";
      }
      inputIngredients.push({
        ingredient: ingred,
        amount: qty,
      });
    }

    let userTags = []
    if (this.state.vegetarian) {
      userTags.push("vegetarian")
    }
    if (this.state.vegan) {
      userTags.push("vegan")
    }
    if (this.state.lactoseIntolerance) {
      userTags.push("lactose intolerance")
    }
    if (this.state.glutenFree) {
      userTags.push("gluten free")
    }

    let data = {
      nameOfRecipe: this.state.title,
      instructions: this.state.instructions,
      recipeIngredients: inputIngredients,
      tags: userTags,
    };

    let resp = await fetch("https://lazy-cook.herokuapp.com/api/recipe/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Token " + this.state.token,
      },
      body: JSON.stringify(data),
    });

    let json = await resp.json();

    if (json.message === "Recipe has been created") {
      let id = json.data;
      if (this.state.image !== undefined) {
        var dataUpload = new FormData();
        dataUpload.append("image", {
          uri: this.state.image,
          name: "new-recipe.jpg",
          type: "image/jpg",
        });
        dataUpload.append("id", id);

        let respUpload = await fetch(
          "https://lazy-cook.herokuapp.com/api/upload/",
          {
            method: "POST",
            headers: {
              "Content-Type": "multipart/form-data",
              Authorization: "Token " + this.state.token,
            },
            body: dataUpload,
          }
        );

        let jsonUpload = await respUpload.json();

        if (jsonUpload.message === "Image has been uploaded") {
          alert("Successfully adding a recipe!");
        }
      } else {
        alert("Successfully adding a recipe!");
      }
      this.setState({
        title: "",
        ingredients: [""],
        quantities: [""],
        instructions: "",
        image: undefined,
        vegan: false,
        vegetarian: false,
        glutenFree: false,
        lactoseIntolerance: false,
      });
    } else if (json.detail === "invalid token") {
      alert("Session expired. Please re-login!")
      const { setUserToken, setUserName } = this.context;
      setUserToken(null);
      setUserName(null);
      authStorage.removeUser("userToken");
      authStorage.removeUser("userName");
    } else {
      alert(json.message)
    }
    this.setState({ disable: false })
  }

  setCameraOn(val) {
    this.setState({
      cameraOn: val,
    });
  }

  async pictureFromCamera(uri, name) {
    this.setState({
      image: uri,
      cameraOn: false,
    });
  }

  async handleInputButton() {
    const { status } = await Camera.requestPermissionsAsync();
    //setHasPermission(status === 'granted');

    if (status === "granted") {
      this.setState({ cameraOn: true });
    }
  }

  render() {
    return (
      <Screen>
        <View>
          <AddCameraModal
            cameraOn={this.state.cameraOn}
            setCameraOn={this.setCameraOn}
            token={this.state.token}
            pictureFromCamera={this.pictureFromCamera}
          />
        </View>
        <View style={styles.topContainer}>
          <Text style={styles.text}>Create a Recipe</Text>
          <Text style={styles.subtext}>
            Follow the steps below to create a new recipe.
          </Text>
        </View>
        <ScrollView
          contentContainerStyle={{ paddingBottom: "20%", paddingTop: "0%" }}
        >
          <View style={styles.bottomContainer}>
            <View style={styles.containerBox}>
              <Text style={styles.title}>Title</Text>
              <View style={styles.fieldContainer}>
                <TextInput
                  style={styles.field}
                  underlineColorAndroid="transparent"
                  placeholder="Enter Title"
                  placeholderTextColor={colors.gray}
                  onChangeText={(value) => this.setState({ title: value })}
                  value={this.state.title}
                />
              </View>
              <View style={styles.separator} />

              <Text style={styles.title}>Instructions</Text>
              <View style={styles.fieldContainer}>
                <TextInput
                  style={styles.field}
                  underlineColorAndroid="transparent"
                  placeholder="Enter Instructions"
                  placeholderTextColor={colors.gray}
                  onChangeText={(value) =>
                    this.setState({ instructions: value })
                  }
                  value={this.state.instructions}
                  multiline={true}
                  blurOnSubmit={true}
                />
              </View>
              <View style={styles.separator} />

              <Text style={styles.title}>Ingredients</Text>
              <FlatList
                contentContainerStyle={styles.selectList}
                data={this.state.ingredients}
                keyExtractor={(item, index) => index.toString()}
                removeClippedSubviews={false}
                renderItem={({ item, index }) => (
                  <View style={styles.fieldContainerWithoutLine}>
                    <TextInput
                      style={styles.fieldIngredient}
                      underlineColorAndroid="transparent"
                      placeholder="Enter Ingredient"
                      placeholderTextColor={colors.gray}
                      onChangeText={(value) => {
                        let { ingredients } = this.state;
                        ingredients[index] = value;
                        this.setState({
                          ingredients,
                        });
                      }}
                      value={this.state.ingredients[index]}
                    />
                    <View style={{ flex: 1 }}>
                      <Text>Qty:</Text>
                    </View>
                    <TextInput
                      style={styles.fieldQuantity}
                      underlineColorAndroid="transparent"
                      placeholder="Quantity"
                      placeholderTextColor={colors.gray}
                      onChangeText={(value) => {
                        let { quantities } = this.state;
                        quantities[index] = value;
                        this.setState({
                          quantities,
                        });
                      }}
                      value={this.state.quantities[index]}
                    />
                  </View>
                )}
              />
              <View style={styles.separator} />

              <View style={styles.addMoreContainer}>
                <TouchableOpacity
                  style={styles.addMore}
                  onPress={() => {
                    this.setState({
                      ingredients: [...this.state.ingredients, ""],
                      quantities: [...this.state.quantities, ""],
                    });
                  }}
                  testID="add-more-button"
                >
                  <Text style={styles.addMoreText}>+ Add More</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.separator} />
              <Text style={styles.title}>Picture</Text>
              <View style={styles.fieldContainerWithoutLineImage}>
                {this.state.image !== undefined ? (
                  <>
                    <Image
                      style={styles.uploadedImage}
                      source={{ uri: this.state.image }}
                    ></Image>
                    <TouchableOpacity testID="reset-image-button"
                      onPress={() => this.setState({ image: undefined })}
                    >
                      <MaterialIcons name="close" color="black" size={30} />
                    </TouchableOpacity>
                  </>
                ) : (
                  <TouchableOpacity
                    style={styles.addPictureButton}
                    onPress={this.handleInputButton}
                    testID="camera-button"
                  >
                    <MaterialCommunityIcons
                      name="camera"
                      color={colors.green}
                      size={40}
                    />
                  </TouchableOpacity>
                )}
              </View>
            </View>

            <View style={styles.separator} />

            <View style={styles.containerBox}>
              <Text style={styles.title}>Tags</Text>
              <View style={styles.fieldContainer2}>
                <Text style={styles.fieldText2}>Vegetarian:</Text>
                <View style={styles.option} testID="vegetarian">
                  <TouchableOpacity
                    style={
                      this.state.vegetarian ? styles.buttonOn : styles.buttonOff
                    }
                    onPress={() =>
                      this.setState({ vegetarian: !this.state.vegetarian })
                    }
                  >
                    <Text
                      style={
                        this.state.vegetarian
                          ? styles.textCenterOn
                          : styles.textCenterOff
                      }
                    >
                      {this.state.vegetarian ? "Yes" : "No"}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.fieldContainer2}>
                <Text style={styles.fieldText2}>Vegan:</Text>
                <View style={styles.option} testID="vegan">
                  <TouchableOpacity
                    style={this.state.vegan ? styles.buttonOn : styles.buttonOff}
                    onPress={() => this.setState({ vegan: !this.state.vegan })}
                  >
                    <Text
                      style={
                        this.state.vegan
                          ? styles.textCenterOn
                          : styles.textCenterOff
                      }
                    >
                      {this.state.vegan ? "Yes" : "No"}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.fieldContainer2}>
                <Text style={styles.fieldText2}>GlutenFree:</Text>
                <View style={styles.option} testID="gluten-free">
                  <TouchableOpacity
                    style={
                      this.state.glutenFree ? styles.buttonOn : styles.buttonOff
                    }
                    onPress={() =>
                      this.setState({ glutenFree: !this.state.glutenFree })
                    }
                  >
                    <Text
                      style={
                        this.state.glutenFree
                          ? styles.textCenterOn
                          : styles.textCenterOff
                      }
                    >
                      {this.state.glutenFree ? "Yes" : "No"}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.fieldContainer2}>
                <Text style={styles.fieldText2}>Lactose Intolerant:</Text>
                <View style={styles.option} testID="lactose-intolerant">
                  <TouchableOpacity
                    style={
                      this.state.lactoseIntolerance
                        ? styles.buttonOn
                        : styles.buttonOff
                    }
                    onPress={() =>
                      this.setState({
                        lactoseIntolerance: !this.state.lactoseIntolerance,
                      })
                    }
                  >
                    <Text
                      style={
                        this.state.lactoseIntolerance
                          ? styles.textCenterOn
                          : styles.textCenterOff
                      }
                    >
                      {this.state.lactoseIntolerance ? "Yes" : "No"}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>

            <View style={styles.separator} />

            <View style={styles.containerBox}>
              <TouchableOpacity onPress={this.handleAdd} style={this.state.disable ? styles.submitDisabled : styles.submit} testID="submit-button" disabled={this.state.disable}>
                <Text style={styles.submitText}>Add Recipe</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </Screen>
    );
  }
}

const styles = StyleSheet.create({
  addMore: {
    width: "40%",
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.white,
    borderColor: colors.green,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 0,
    borderWidth: 2,
  },
  addMoreContainer: {
    justifyContent: "center",
    alignItems: "center",
  },
  addMoreText: {
    fontSize: 15,
    fontFamily: "Arial",
    color: colors.green,
  },
  addPictureButton: {
    borderStyle: "dotted",
    borderWidth: 5,
    width: 60,
    height: 60,
    borderColor: colors.green,
    justifyContent: "center",
    alignItems: "center",
  },
  backButton: {
    height: 30,
  },
  bottomContainer: {
    width: "100%",
    paddingHorizontal: 25,
    flex: 1,
  },
  button: {
    width: 70,
    right: 25,
    top: 25,
    position: "absolute",
  },
  buttonText: {
    color: "blue",
    fontFamily: "Arial",
    fontSize: 15,
  },
  containerBox: {
    marginHorizontal: 5,
  },
  field: {
    flex: 1,
    paddingHorizontal: 5,
  },
  fieldIngredient: {
    flex: 7,
    paddingHorizontal: 5,
    borderBottomColor: colors.medium,
    borderBottomWidth: 1,
  },
  fieldQuantity: {
    flex: 3,
    paddingHorizontal: 5,
    borderBottomColor: colors.medium,
    borderBottomWidth: 1,
  },
  fieldContainer: {
    width: "100%",
    borderBottomColor: colors.medium,
    borderBottomWidth: 1,
    flexDirection: "row",
    marginBottom: 10,
    alignItems: "center",
    justifyContent: "space-between",
    marginLeft: 5,
  },
  fieldContainer2: {
    flex: 1,
    width: "100%",
    flexDirection: "row",
    marginBottom: 0,
    height: 50,
    alignItems: "center",
    justifyContent: "space-between",
  },
  fieldContainerWithoutLine: {
    width: "100%",
    flexDirection: "row",
    marginBottom: 5,
    alignItems: "center",
    justifyContent: "space-between",
    marginLeft: 5,
  },
  fieldContainerWithoutLineImage: {
    width: "100%",
    flexDirection: "row",
    marginBottom: 5,
    alignItems: "center",
    justifyContent: "flex-start",
    marginLeft: 10,
  },
  fieldText0: {
    padding: 5,
    width: 60,
  },
  fieldText: {
    padding: 5,
    width: 90,
  },
  fieldText2: {
    padding: 5,
  },
  navigator: {
    width: "100%",
    position: "absolute",
    bottom: -15,
    backgroundColor: colors.primary,
  },
  option: {
    width: 100,
  },
  separator: {
    width: "100%",
    height: 15,
  },
  subtext: {
    color: colors.medium,
    fontSize: 15,
    paddingLeft: 10,
  },
  subtext2: {
    color: colors.medium,
    fontSize: 15,
    paddingLeft: 5,
    marginVertical: 10,
    paddingBottom: 5,
  },
  submit: {
    width: "100%",
    height: 50,
    borderRadius: 20,
    backgroundColor: colors.green,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 20,
  },
  submitDisabled: {
    width: "100%",
    height: 50,
    borderRadius: 20,
    backgroundColor: "#ccc",
    color: "#999",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 20,
  },
  submitText: {
    fontSize: 15,
    fontFamily: "Arial",
    color: colors.white,
  },
  topContainer: {
    width: "100%",
    padding: 25,
  },
  text: {
    color: colors.green,
    fontWeight: "800",
    fontSize: 25,
    fontFamily: "Arial",
    paddingLeft: 10,
    marginBottom: 20,
  },
  title: {
    color: colors.black,
    fontWeight: "800",
    fontSize: 25,
    fontFamily: "Arial",
    paddingLeft: 5,
    marginBottom: 10,
  },
  uploadedImage: {
    width: 100,
    height: 100,
  },
  textCenterOn: {
    textAlign: "center",
    color: colors.white,
  },
  textCenterOff: {
    textAlign: "center",
    color: colors.green,
  },
  buttonOn: {
    backgroundColor: colors.green,
    borderRadius: 10,
    width: "100%",
  },
  buttonOff: {
    backgroundColor: colors.white,
    borderColor: colors.green,
    borderRadius: 10,
    width: "100%",
    borderWidth: 1,
  },
});
export default AddRecipeScreen;
