import React, { useState } from "react";
import {
  Button,
  StyleSheet,
  TouchableOpacity,
  View,
  Text,
  FlatList,
} from "react-native";
import InfiniteScroll from "react-infinite-scroller";
import Feather from "react-native-vector-icons/Feather";

import Card from "./components/Card";
import colors from "./config/colors";
import Screen from "./components/Screen";

import authStorage from "./auth/storage";
import AuthContext from "./auth/context";

const dummy = [
  {
    id: 11,
    name: "Poke Bowl",
    steps: [
      "Mix any kind of rice with vinegar and sugar",
      "Add sesame seeds",
      "Add toppings of choice",
      "Add soy sauce and wasabi",
    ],
    description: "Yummy DIY poke bowl.",
    images: ["img_recipe_no_13_1.jpg", "img_recipe_no_13_2.jpg"],
    ingredients: ["Rice", "Soy Sauce", "Wasabi", "Vinegar", "Sugar"],
    tags: ["Gluten free"],
    creator: "testuser1",
  },
  {
    id: 30,
    name: "Salmon Nigiri",
    steps: [
      "Mix any kind of rice with vinegar and sugar",
      "Make sushi rice",
      "Add sliced salmon on top of the rice",
      "Serve with soy sauce and wasabi",
    ],
    description:
      "Salmon nigiri consists of a slice of raw salmon served over pressed vinegar rice." +
      "Salmon sashimi is not sushi, and doesn't have rice. It refers to just slices of raw" +
      "salmon, often served over shredded daikon radish.",
    images: ["img_recipe_no_30_1.jpg"],
    ingredients: ["Rice", "Soy Sauce", "Wasabi", "Vinegar", "Sugar"],
    tags: ["Lactose Intolerance", "Gluten free"],
    creator: "none",
  },
];

class SearchResultsScreen extends React.Component {
  static contextType = AuthContext;
  constructor(props) {
    super(props);
    this.state = {
      currentPage: 1,
      data: [],
    };

    this.componentDidMount = this.componentDidMount.bind(this);
    this.handleLoadMore = this.handleLoadMore.bind(this);
  }

  async componentDidMount() {
    let ext =
      this.props.route.params.ingredients === "" ? "" : "/?Ingredients=";
    let page =
      this.props.route.params.ingredients === ""
        ? "/?Page=" + this.state.currentPage
        : "&Page=" + this.state.currentPage;
    let resp = await fetch(
      "https://lazy-cook.herokuapp.com/api/recipe" +
      ext +
      this.props.route.params.ingredients +
      page,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Token " + this.props.route.params.token,
        },
      }
    );
    let json = await resp.json();
    if (json.message === "Successful Display of recipes") {
      this.setState({
        data: json.data,
        currentPage: this.state.currentPage + 1,
      });
    } else if (json.detail === "invalid token") {
      alert("Session expired. Please re-login!");
      const { setUserToken, setUserName } = this.context;
      setUserToken(null);
      setUserName(null);
      authStorage.removeUser("userToken");
      authStorage.removeUser("userName");
    }
  }

  async handleLoadMore(distanceFromEnd) {
    let ext =
      this.props.route.params.ingredients === "" ? "" : "/?Ingredients=";
    let page =
      this.props.route.params.ingredients === ""
        ? "/?Page=" + this.state.currentPage
        : "&Page=" + this.state.currentPage;
    let resp = await fetch(
      "https://lazy-cook.herokuapp.com/api/recipe" +
      ext +
      this.props.route.params.ingredients +
      page,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Token " + this.props.route.params.token,
        },
      }
    );
    let json = await resp.json();

    if (json.message === "Successful Display of recipes") {
      this.setState({
        data: [...this.state.data, ...json.data],
        currentPage: this.state.currentPage + 1,
      });
    } else if (json.detail === "invalid token") {
      alert("Session expired. Please re-login!");
      const { setUserToken, setUserName } = this.context;
      setUserToken(null);
      setUserName(null);
      authStorage.removeUser("userToken");
      authStorage.removeUser("userName");
    }
  }

  render() {
    return (
      <Screen>
        <View style={styles.topContainer}>
          <TouchableOpacity
            style={styles.backButton}
            testID="back-button"
            onPress={() =>
              this.props.navigation.navigate("SearchByIngredientsScreen")
            }
          >
            <Feather name="arrow-left" color={colors.green} size={30} />
          </TouchableOpacity>
          <Text style={styles.text}>Search Results...</Text>
        </View>
        <View style={styles.bottomContainer}>
          <View style={styles.separator} />
          <FlatList
            data={this.state.data}
            keyExtractor={(item, index) => {
              return item.recipeID.toString();
            }}
            testID="recipe-list"
            removeClippedSubviews={true}
            renderItem={({ item }) => (
              <Card
                title={item.nameOfRecipe}
                image={item.image}
                key={item.recipeID}
                onPress={() =>
                  this.props.navigation.navigate("SpecificRecipeScreen", {
                    prevScreen: "SearchResultsScreen",
                    name: item.nameOfRecipe,
                    ingred: item.ingredients,
                    image: item.image,
                    step: item.instructions,
                    user: this.props.route.params.user,
                    token: this.props.route.params.token,
                    id: item.recipeID,
                  })
                }
              />
            )}
            onEndReached={(distanceFromEnd) =>
              this.handleLoadMore(distanceFromEnd)
            }
            onEndReachedThreshold={0.01}
            initialNumToRender={10}
          />
        </View>
      </Screen>
    );
  }
}

const styles = StyleSheet.create({
  backButton: {
    height: 30,
  },
  bottomContainer: {
    width: "100%",
    paddingHorizontal: 25,
    paddingTop: 10,
    flex: 1,
  },
  button: {
    width: 70,
    right: 25,
    top: 25,
    position: "absolute",
  },
  buttonText: {
    color: "blue",
    fontFamily: "Arial",
    fontSize: 15,
  },
  separator: {
    width: "100%",
    height: 10,
  },
  topContainer: {
    width: "100%",
    height: 80,
    padding: 25,
    flexDirection: "row",
  },
  text: {
    color: colors.green,
    fontWeight: "800",
    fontSize: 25,
    fontFamily: "Arial",
    paddingLeft: 10,
  },
});
export default SearchResultsScreen;
