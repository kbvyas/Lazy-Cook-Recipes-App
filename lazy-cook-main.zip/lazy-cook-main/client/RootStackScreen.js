import React from "react";

import { createStackNavigator } from "@react-navigation/stack";

import SplashScreen from "./SplashScreen";
import SignInScreen from "./SignInScreen";
import SignUpScreen from "./SignUpScreen";
import ProfileScreen from "./ProfileScreen";
import SearchByIngredientsScreen from "./SearchByIngredientsScreen";
import SearchResultsScreen from "./SearchResultsScreen";
import SpecificRecipeScreen from "./SpecificRecipeScreen";
import AddRecipeScreen from "./AddRecipeScreen";
import SavedRecipesScreen from "./SavedRecipesScreen";

const RootStack = createStackNavigator();

class RootStackScreen extends React.Component {
  render() {
    return (
      <RootStack.Navigator headerMode="none">
        <RootStack.Screen name="SplashScreen" component={SplashScreen} />
        <RootStack.Screen name="SignInScreen" component={SignInScreen} />
        <RootStack.Screen name="SignUpScreen" component={SignUpScreen} />
        <RootStack.Screen name="ProfileScreen" component={ProfileScreen} />
        <RootStack.Screen
          name="SearchResultsScreen"
          component={SearchResultsScreen}
        />
        <RootStack.Screen
          name="SearchByIngredientsScreen"
          component={SearchByIngredientsScreen}
        />
        <RootStack.Screen
          name="SpecificRecipeScreen"
          component={SpecificRecipeScreen}
        />
        <RootStack.Screen name="AddRecipeScreen" component={AddRecipeScreen} />
        <RootStack.Screen
          name="SavedRecipesScreen"
          component={SavedRecipesScreen}
        />
      </RootStack.Navigator>
    );
  }
}

export default RootStackScreen;
