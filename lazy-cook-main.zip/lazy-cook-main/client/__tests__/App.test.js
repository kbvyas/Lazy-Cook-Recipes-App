jest.useFakeTimers()
window.alert = jest.fn();

import React from 'react';
import renderer from 'react-test-renderer';
import { render, fireEvent, waitFor, waitForElementToBeRemoved, update } from '@testing-library/react-native';

import {
  Text,
  TouchableOpacity
} from "react-native";

import App from '../App';
import RootStackScreen from '../RootStackScreen';
import SignInScreen from '../SignInScreen';
import SignUpScreen from '../SignUpScreen';
import SearchByIngredientsScreen from '../SearchByIngredientsScreen';
import SearchResultsScreen from '../SearchResultsScreen'
import SpecificRecipeScreen from '../SpecificRecipeScreen'
import CameraModal from '../components/CameraModal'
import Card from '../components/Card'
import AppTextInput from '../components/AppTextInput'
import ProfileScreen from '../ProfileScreen'
import AppNavigator from '../navigation/AppNavigator'
import SavedNavigator from '../navigation/SavedNavigator'
import AddRecipeScreen from '../AddRecipeScreen';
import SavedRecipesScreen from '../SavedRecipesScreen'
import AddCameraModal from '../components/AddCameraModal'

import { NavigationContainer } from '@react-navigation/native';
import { Camera } from 'expo-camera';

import AuthContext from "../auth/context"

const customRender = (ui, { providerProps, ...renderOptions }) => {
  return render(
    <AuthContext.Provider value={providerProps}>{ui}</AuthContext.Provider>,
    renderOptions
  )
}

beforeEach(() => {
  jest.spyOn(console, 'error').mockImplementation(() => {});
  fetch.resetMocks();
});

describe('<App /> setup', () => {
  it('has 1 child', () => {
    const tree = renderer.create(<App />).toJSON();
    expect(tree.children.length).toBe(1);
  });
});


test('Context ProfileScreen', async () => {
  const providerProps = {
    userName: 'test1',
    userToken: "token1",
    setUserName: () => { },
    setUserToken: () => { },
  }
  const { getByTestId } = customRender(<ProfileScreen />, { providerProps })
  //const { getByTestId } = render(<ProfileScreen />);
  expect(getByTestId('username')).toBeDefined()
});

test('login with valid username and password', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "token1",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const { getByText, getByPlaceholderText } = customRender(<SignInScreen />, { providerProps });

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Username').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Password').props.value).toBe('test1');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'login success',
    token: 'weeeeeeeeeeeee'
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  //console.log(resp.body.toString('utf8'))

  fireEvent(getByText('Sign In'), 'press');

  expect(fetch.mock.calls.length).toEqual(1)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/login?format=json')
});

test('login with invalid username and password', async () => {

  const { getByText, getByPlaceholderText } = render(<SignInScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Username').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', 'test2');
  expect(getByPlaceholderText('Your Password').props.value).toBe('test2');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'invalid username and/or password',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fireEvent(getByText('Sign In'), 'press');

  expect(fetch.mock.calls.length).toEqual(1)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/login?format=json')
});

test('login with no username set', async () => {

  const { getByText, getByPlaceholderText } = render(<SignInScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', '');
  expect(getByPlaceholderText('Your Username').props.value).toBe('');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Password').props.value).toBe('test1');

  fireEvent(getByText('Sign In'), 'press');
});

test('login with no password set', async () => {

  const { getByText, getByPlaceholderText } = render(<SignInScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Username').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', '');
  expect(getByPlaceholderText('Your Password').props.value).toBe('');

  fireEvent(getByText('Sign In'), 'press');
});

test('login setting no change in username', async () => {

  const { getByPlaceholderText } = render(<SignInScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', '');
  expect(getByPlaceholderText('Your Username').props.value).toBe('');
});

test('login go to sign-up', async () => {
  const { getByText } = render(<SignInScreen />);

  fireEvent(getByText('Sign Up'), 'press');
});

test('renders the correct screen', () => {
  const { getByText } = render(
    <NavigationContainer>
      <RootStackScreen />
    </NavigationContainer>
  );
});

test('login change password view toogle', async () => {

  const { getByTestId } = render(<SignInScreen />);

  fireEvent(getByTestId('eye'), 'press');
});

test('app', async () => {
  const { getByTestId, update } = render(<App />);
  expect(getByTestId("loading")).toBeDefined()
});

test('app after loading', async () => {
  const { getByTestId, update } = render(<App />);
  jest.runTimersToTime(1000)
  expect(getByTestId('loading')).toBeDefined()
});

test('signup with valid username, password, and email', async () => {

  const { getByText, getByPlaceholderText } = render(<SignUpScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Username').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Password').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Email'), 'changeText', 'test1@gmail.com');
  expect(getByPlaceholderText('Your Email').props.value).toBe('test1@gmail.com');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'sign-up success',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  //console.log(resp.body.toString('utf8'))

  fireEvent(getByText('Sign Up'), 'press');

  expect(fetch.mock.calls.length).toEqual(1)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/signup?format=json')
});

test('signup with missing username', async () => {

  const { getByText, getByPlaceholderText } = render(<SignUpScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', '');
  expect(getByPlaceholderText('Your Username').props.value).toBe('');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Password').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Email'), 'changeText', 'test1@gmail.com');
  expect(getByPlaceholderText('Your Email').props.value).toBe('test1@gmail.com');

  fireEvent(getByText('Sign Up'), 'press');
});

test('signup with missing password', async () => {

  const { getByText, getByPlaceholderText } = render(<SignUpScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Username').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', '');
  expect(getByPlaceholderText('Your Password').props.value).toBe('');

  fireEvent(getByPlaceholderText('Your Email'), 'changeText', 'test1@gmail.com');
  expect(getByPlaceholderText('Your Email').props.value).toBe('test1@gmail.com');

  fireEvent(getByText('Sign Up'), 'press');
});

test('signup with missing email', async () => {

  const { getByText, getByPlaceholderText } = render(<SignUpScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Username').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Password').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Email'), 'changeText', '');
  expect(getByPlaceholderText('Your Email').props.value).toBe('');

  fireEvent(getByText('Sign Up'), 'press');
});

test('signup with valid duplicated username', async () => {

  const { getByText, getByPlaceholderText } = render(<SignUpScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Username').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Password').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Email'), 'changeText', 'test1@gmail.com');
  expect(getByPlaceholderText('Your Email').props.value).toBe('test1@gmail.com');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'username taken',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  //console.log(resp.body.toString('utf8'))

  fireEvent(getByText('Sign Up'), 'press');

  expect(fetch.mock.calls.length).toEqual(1)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/signup?format=json')
});

test('signup with valid invalid email', async () => {

  const { getByText, getByPlaceholderText } = render(<SignUpScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Username').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Password').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Email'), 'changeText', 'test1@gmail.com');
  expect(getByPlaceholderText('Your Email').props.value).toBe('test1@gmail.com');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'invalid email',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  //console.log(resp.body.toString('utf8'))

  fireEvent(getByText('Sign Up'), 'press');

  expect(fetch.mock.calls.length).toEqual(1)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/signup?format=json')
});

test('signup password too short', async () => {

  const { getByText, getByPlaceholderText } = render(<SignUpScreen />);

  fireEvent(getByPlaceholderText('Your Username'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Username').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Password'), 'changeText', 'test1');
  expect(getByPlaceholderText('Your Password').props.value).toBe('test1');

  fireEvent(getByPlaceholderText('Your Email'), 'changeText', 'test1@gmail.com');
  expect(getByPlaceholderText('Your Email').props.value).toBe('test1@gmail.com');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'password too short',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  //console.log(resp.body.toString('utf8'))

  fireEvent(getByText('Sign Up'), 'press');

  expect(fetch.mock.calls.length).toEqual(1)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/signup?format=json')
});

test('signup change password view toogle', async () => {

  const { getByTestId } = render(<SignUpScreen />);

  fireEvent(getByTestId('eye'), 'press');
});

test('searchbyingredients', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const { getByPlaceholderText } = customRender(<SearchByIngredientsScreen />, { providerProps });

  fireEvent(getByPlaceholderText("Search by text or camera"), 'changeText', '');
  expect(getByPlaceholderText("Search by text or camera").props.value).toBe('');

  fireEvent(getByPlaceholderText("Search by text or camera"), 'submitEditing');

  fireEvent(getByPlaceholderText("Search by text or camera"), 'changeText', 'broccoli');
  expect(getByPlaceholderText("Search by text or camera").props.value).toBe('broccoli');

  fireEvent(getByPlaceholderText("Search by text or camera"), 'submitEditing');
  expect(getByPlaceholderText("Search by text or camera").props.value).toBe('');
});

test('searchbyingredients input from camera', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const { getByTestId } = customRender(<SearchByIngredientsScreen />, { providerProps });

  expect(getByTestId("ingredients")).toBeDefined;
});

test('searchbyingredients submit empty', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const { getByTestId } = customRender(<SearchByIngredientsScreen />, { providerProps });

  expect(getByTestId("submit")).toBeDefined;

  fireEvent(getByTestId("submit"), 'press');
});

test('searchbyingredients submit', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const navigate = jest.fn();

  const { getByTestId, getByPlaceholderText } = customRender(<SearchByIngredientsScreen navigation={{ navigate }} />, { providerProps });

  fireEvent(getByPlaceholderText("Search by text or camera"), 'changeText', 'broccoli,cheese');
  expect(getByPlaceholderText("Search by text or camera").props.value).toBe('broccoli,cheese');

  fireEvent(getByPlaceholderText("Search by text or camera"), 'submitEditing');
  expect(getByPlaceholderText("Search by text or camera").props.value).toBe('');

  fireEvent(getByPlaceholderText("Search by text or camera"), 'changeText', 'broccoli,cheese');
  expect(getByPlaceholderText("Search by text or camera").props.value).toBe('broccoli,cheese');

  fireEvent(getByPlaceholderText("Search by text or camera"), 'submitEditing');
  expect(getByPlaceholderText("Search by text or camera").props.value).toBe('');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Successful Display of recipes',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fireEvent(getByTestId("submit"), 'press');

  expect(navigate).toHaveBeenCalledWith('SearchResultsScreen', { "ingredients": "broccoli,cheese", "token": "test", "user": "test1" });
});

test('searchbyingredients press camera button', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const { getByTestId, getByPlaceholderText } = customRender(<SearchByIngredientsScreen />, { providerProps });

  //console.log(getByTestId('input-method').props.children[1].props.children[0].props)

  let item = {
    title: "camera",
    icon: {
      nameOn: "camera",
      backgroundColor: "black",
    },
  };

  fireEvent(getByTestId('input-method').props.renderItem({ item: item }), "press")

});

test('searchbyingredients handleDelete', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const { getByTestId, getByPlaceholderText } = customRender(<SearchByIngredientsScreen />, { providerProps });

  fireEvent(getByPlaceholderText("Search by text or camera"), 'changeText', 'broccoli');
  expect(getByPlaceholderText("Search by text or camera").props.value).toBe('broccoli');

  fireEvent(getByPlaceholderText("Search by text or camera"), 'submitEditing');
  expect(getByPlaceholderText("Search by text or camera").props.value).toBe('');

  let item = {
    label: "broccoli"
  };

  fireEvent(getByTestId('ingredient-list').props.renderItem({ item: item }), "press")

});

test('searchbyingredients function testing', async () => {
  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const component = renderer.create(<AuthContext.Provider value={providerProps}>
    <SearchByIngredientsScreen />
  </AuthContext.Provider>)
  component.root.instance.setCameraOn(true)
  component.root.instance.ingredientsFromCamera(["onion"], "success")
  component.root.instance.ingredientsFromCamera(undefined, "failed")
});

test('CameraModal', async () => {

  const setCameraOn = () => { }

  const ingredientsFromCamera = () => { }

  const { getByTestId, getByPlaceholderText } = render(<CameraModal cameraOn={false} setCameraOn={setCameraOn} token="test1" ingredientsFromCamera={ingredientsFromCamera} />);

  fireEvent(getByTestId("type-button"), 'press');

  fireEvent(getByTestId("close-button-2"), 'press');

  fireEvent(getByTestId("flash-button"), 'press');

  fireEvent(getByTestId("picker-button"), 'press');

  fireEvent(getByTestId("flash-button"), 'press');

  fetch.mockResponseOnce(JSON.stringify({
    "message": "Successful predict ingredient",
    "data": ["carrot", "onion"],
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fireEvent(getByTestId("snap-button"), 'press');
});


test('searchResultScreen back', async () => {

  let param = { params: { token: "test" } };

  const navigate = jest.fn();

  const { getByTestId, getByPlaceholderText } = render(<SearchResultsScreen route={param} navigation={{ navigate }} />);

  fireEvent(getByTestId("back-button"), 'press');

  expect(navigate).toHaveBeenCalledWith('SearchByIngredientsScreen');
});

test('searchResultScreen', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  let param = { params: { token: "test", ingredients: "Carrot" } };

  const navigate = jest.fn();

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Successful Display of recipes',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  const { getByTestId, getByPlaceholderText } = customRender(<SearchResultsScreen route={param} navigation={{ navigate }} />, { providerProps });

  expect(fetch.mock.calls.length).toEqual(1)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/api/recipe/?Ingredients=Carrot&Page=1')

  let item = {
    recipeID: "2",
    nameOfRecipe: "broccoli",
    ingred: ["broccoli"],
    image: "broccoli.jpg",
    step: ["step1"],
    token: "test"
  };

  fireEvent(getByTestId('recipe-list').props.renderItem({ item: item }), "press")

  expect(navigate).toHaveBeenCalledWith("SpecificRecipeScreen", { "id": "2", "image": "broccoli.jpg", "ingred": undefined, "name": "broccoli", "prevScreen": "SearchResultsScreen", "step": undefined, "token": "test" });

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Successful Display of recipes',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fireEvent(getByTestId('recipe-list'), "endReached")

});

test('searchResultScreen invalid token', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  let param = { params: { token: "test", ingredients: "Carrot" } };

  const navigate = jest.fn();

  fetch.mockResponseOnce(JSON.stringify({
    detail: 'invalid token',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  const { getByTestId, getByPlaceholderText } = customRender(<SearchResultsScreen route={param} navigation={{ navigate }} />, { providerProps });

  expect(fetch.mock.calls.length).toEqual(1)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/api/recipe/?Ingredients=Carrot&Page=1')
})

test('searchResultScreen handleLoadMore invalid token', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  let param = { params: { token: "test", ingredients: "Carrot" } };

  const navigate = jest.fn();

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Successful Display of recipes',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  const { getByTestId, getByPlaceholderText } = customRender(<SearchResultsScreen route={param} navigation={{ navigate }} />, { providerProps });

  expect(fetch.mock.calls.length).toEqual(1)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/api/recipe/?Ingredients=Carrot&Page=1')

  let item = {
    recipeID: "2",
    nameOfRecipe: "broccoli",
    ingred: ["broccoli"],
    image: "broccoli.jpg",
    step: ["step1"],
    token: "test"
  };

  fireEvent(getByTestId('recipe-list').props.renderItem({ item: item }), "press")

  expect(navigate).toHaveBeenCalledWith("SpecificRecipeScreen", { "id": "2", "image": "broccoli.jpg", "ingred": undefined, "name": "broccoli", "prevScreen": "SearchResultsScreen", "step": undefined, "token": "test" });

  fetch.mockResponseOnce(JSON.stringify({
    detail: 'invalid token',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fireEvent(getByTestId('recipe-list'), "endReached")

});

test('SpecificRecipeScreen', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  let param = { params: { token: "test", id: "7", ingred: "broccoli" } };

  const navigate = jest.fn();

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Displaying Ratings for Recipe',
    data: [{ "ratingValue": "4", "ratingReview": "Taste like a real broccoli. Really love it!" }, { "ratingValue": "1", "ratingReview": "Ewh, broccoli!" }]
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  const { getByTestId, getByPlaceholderText } = customRender(<SpecificRecipeScreen route={param} navigation={{ navigate }} />, { providerProps });

  getByTestId("star-rating").props.children[1].props.selectedStar(3)

  fireEvent(getByPlaceholderText("Add your review here"), 'changeText', "review");

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Made Rating for Recipe',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fireEvent(getByTestId("submit-review"), 'press');

  expect(fetch.mock.calls.length).toEqual(2)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/api/recipe/7/ratings/')

  fetch.mockResponseOnce(JSON.stringify({
    detail: 'invalid token',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fireEvent(getByTestId("submit-review"), 'press');

  fireEvent(getByTestId("expand-ingredients"), 'press');
  fireEvent(getByTestId("expand-instructions"), 'press');
  fireEvent(getByTestId("expand-reviews"), 'press');
  fireEvent(getByTestId("expand-comment"), 'press');
  fireEvent(getByTestId("expand-review"), 'press');
});

test('SpecificRecipeScreen back', async () => {

  let param = { params: { token: "test", id: "2", ingred: "broccoli" } };

  const navigate = jest.fn();

  const { getByTestId, getByPlaceholderText } = render(<SpecificRecipeScreen route={param} navigation={{ navigate }} />);

  fireEvent(getByTestId("back-button"), 'press');

  expect(navigate).toHaveBeenCalledWith("SavedRecipesScreen", { "token": "test", "user": undefined });

});

test('SpecificRecipeScreen bookmark', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  let param = { params: { token: "test", id: "2", ingred: "broccoli" } };

  const { getByTestId, getByPlaceholderText } = customRender(<SpecificRecipeScreen route={param} />, { providerProps });

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Recipe was successfully saved'
  }))

  fireEvent(getByTestId("bookmark-button"), 'press');

  fetch.mockResponseOnce(JSON.stringify({
    detail: 'invalid token'
  }))

  fireEvent(getByTestId("bookmark-button"), 'press');

});

test('SpecificRecipeScreen bookmark 2', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  let param = { params: { token: "test", id: "2", ingred: "broccoli" } };

  const { getByTestId, getByPlaceholderText } = customRender(<SpecificRecipeScreen route={param} />, { providerProps });

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Recipe was successfully saved'
  }))

  fireEvent(getByTestId("bookmark-button"), 'press');
  fireEvent(getByTestId("bookmark-button"), 'press');
});

test('SpecificRecipeScreen invalid token', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  let param = { params: { token: "test", id: "7", ingred: "broccoli" } };

  const navigate = jest.fn();

  fetch.mockResponseOnce(JSON.stringify({
    detail: 'invalid token',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  const { getByTestId, getByPlaceholderText } = customRender(<SpecificRecipeScreen route={param} navigation={{ navigate }} />, { providerProps });

  expect(fetch.mock.calls.length).toEqual(1)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/api/recipe/7/ratings/')
});

test('SpecificRecipeScreen second mock', async () => {

  let param = { params: { token: "test", id: "7", ingred: "broccoli" } };

  const navigate = jest.fn();

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Displaying Ratings for Recipe',
    data: [{ "ratingValue": "4", "ratingReview": "Taste like a real broccoli. Really love it!" }, { "ratingValue": "1", "ratingReview": "Ewh, broccoli!" }]
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Displaying Saved Recipe',
    data: { "name": "test" }
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  const { getByTestId, getByPlaceholderText } = render(<SpecificRecipeScreen route={param} navigation={{ navigate }} />);

  expect(fetch.mock.calls.length).toEqual(1)
});

test('SpecificRecipeScreen second mock failed', async () => {

  let param = { params: { token: "test", id: "7", ingred: "broccoli,cheese" } };

  const navigate = jest.fn();

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Displaying Ratings for Recipe',
    data: [{ "ratingValue": "4", "ratingReview": "Taste like a real broccoli. Really love it!" }, { "ratingValue": "1", "ratingReview": "Ewh, broccoli!" }]
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fetch.mockResponseOnce(JSON.stringify({
    message: 'User has not saved this recipe',
    data: { "name": "test" }
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  const { getByTestId, getByPlaceholderText } = render(<SpecificRecipeScreen route={param} navigation={{ navigate }} />);

  expect(fetch.mock.calls.length).toEqual(1)
});

test('Card', async () => {
  const { getByTestId } = render(<Card />);
  expect(getByTestId('card-component')).toBeDefined()
});

test('AppTextInput', async () => {
  const { getByTestId } = render(<AppTextInput />);
  expect(getByTestId('app-text-input')).toBeDefined()
});

test('AppNavigator', async () => {
  const navigate = jest.fn();

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const { getByTestId, getByPlaceholderText } = customRender(<NavigationContainer>
    <AppNavigator navigation={{ navigate }} username="test1" token="test1" />
  </NavigationContainer>, { providerProps });
});

test('ProfileScreen', async () => {
  const navigate = jest.fn();

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  fetch.mockResponseOnce(JSON.stringify({
    message: 'success',
    data: {
      email: "test1",
      vegetarian: false,
      vegan: false,
      glutenFree: false,
      lactoseIntolerance: false,
    }
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  let param = { params: { token: "test", user: "test" } };

  const { getByTestId, getByPlaceholderText } = customRender(<ProfileScreen navigation={{ navigate }} route={param} />, { providerProps });
  expect(getByPlaceholderText('password')).toBeDefined()

  fireEvent(getByTestId("username"), 'changeText', "test1");
  expect(getByTestId('username').props.value).toBe('test1');

  fireEvent(getByPlaceholderText("password"), 'changeText', "password");
  expect(getByPlaceholderText('password').props.value).toBe('password');

  fireEvent(getByTestId("email"), 'changeText', "email@gmail.com");
  expect(getByTestId('email').props.value).toBe('email@gmail.com');

  fireEvent(getByTestId("vegetarian").children[0], 'press');
  fireEvent(getByTestId("vegan").children[0], 'press');
  fireEvent(getByTestId("gluten-free").children[0], 'press');
  fireEvent(getByTestId("lactose-intolerant").children[0], 'press');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'update success',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fireEvent(getByTestId("submit-button"), 'press');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'update failed',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  fireEvent(getByTestId("submit-button"), 'press');

  expect(fetch.mock.calls.length).toEqual(2)
  expect(fetch.mock.calls[0][0]).toEqual('https://lazy-cook.herokuapp.com/account/test1/')
});

test('ProfileScreen invalid token', async () => {
  const navigate = jest.fn();

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  fetch.mockResponseOnce(JSON.stringify({
    detail: 'invalid token',
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  let param = { params: { token: "test", user: "test" } };

  const { getByTestId, getByPlaceholderText } = customRender(<ProfileScreen navigation={{ navigate }} route={param} />, { providerProps });
})

test('profile logout', async () => {
  const navigate = jest.fn();

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  fetch.mockResponseOnce(JSON.stringify({
    message: 'success',
    data: {
      email: "test1",
      vegetarian: false,
      vegan: false,
      glutenFree: false,
      lactoseIntolerance: false,
    }
  }))
  fetch.mockReject(() => Promise.reject("API is down"));

  let param = { params: { token: "test", user: "test" } };

  const component = renderer.create(<AuthContext.Provider value={providerProps}>
    <ProfileScreen navigation={{ navigate }} route={param} />
  </AuthContext.Provider>)

  component.root.instance.handleLogout()
  component.root.instance.handleAlert()
});

test('AddRecipeScreen', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const { getByTestId, getByPlaceholderText } = customRender(<AddRecipeScreen />, { providerProps });

  fireEvent(getByPlaceholderText('Enter Title'), 'changeText', 'recipe title');
  expect(getByPlaceholderText('Enter Title').props.value).toBe('recipe title');

  fireEvent(getByPlaceholderText('Enter Instructions'), 'changeText', 'just cook it');
  expect(getByPlaceholderText('Enter Instructions').props.value).toBe('just cook it');

  fireEvent(getByPlaceholderText('Enter Ingredient'), 'changeText', 'broccoli');
  expect(getByPlaceholderText('Enter Ingredient').props.value).toBe('broccoli');

  fireEvent(getByTestId("vegetarian").children[0], 'press');
  fireEvent(getByTestId("vegan").children[0], 'press');
  fireEvent(getByTestId("gluten-free").children[0], 'press');
  fireEvent(getByTestId("lactose-intolerant").children[0], 'press');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Recipe has been created'
  }))

  fireEvent(getByTestId("submit-button"), 'press');

  fireEvent(getByPlaceholderText('Quantity'), 'changeText', '1 pcs');
  expect(getByPlaceholderText('Quantity').props.value).toBe('1 pcs');

  fireEvent(getByTestId("add-more-button"), 'press');

  fetch.mockResponseOnce(JSON.stringify({
    detail: 'invalid token'
  }))

  fireEvent(getByTestId("submit-button"), 'press');

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Random message'
  }))

  fireEvent(getByTestId("submit-button"), 'press');

  const component = renderer.create(<AuthContext.Provider value={providerProps}>
    <AddRecipeScreen />
  </AuthContext.Provider>)
  component.root.instance.setState({ image: "not undefined" })

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Recipe has been created'
  }))

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Image has been uploaded'
  }))

  component.root.instance.handleAdd()
  component.root.instance.setCameraOn(true)
  component.root.instance.pictureFromCamera("uri", "name.jpg")
  component.root.instance.handleInputButton()
});

test('AddCameraModal', async () => {

  const setCameraOn = () => { }

  const pictureFromCamera = () => { }

  const { getByTestId, getByPlaceholderText } = render(<AddCameraModal cameraOn={false} setCameraOn={setCameraOn} pictureFromCamera={pictureFromCamera} />);

  fireEvent(getByTestId("type-button"), 'press');

  fireEvent(getByTestId("close-button-2"), 'press');

  fireEvent(getByTestId("flash-button"), 'press');

  fireEvent(getByTestId("picker-button"), 'press');

  fireEvent(getByTestId("flash-button"), 'press');

  fireEvent(getByTestId("snap-button"), 'press');
});

test('SavedRecipesScreen', async () => {

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const addListener = jest.fn();

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Displaying Saved Recipes'
  }))

  // const { getByTestId, getByPlaceholderText } = customRender(<SavedRecipesScreen navigation={{ addListener }} />, { providerProps });

  const component = renderer.create(<AuthContext.Provider value={providerProps}>
    <SavedRecipesScreen navigation={{ addListener }} />
  </AuthContext.Provider>)

  let item = {
    "recipeID": 41,
    "recipeAuthor": "admin",
    "dateCreatedOn": "2021-04-16T20:16:47.891266Z",
    "nameOfRecipe": "Toast and eggs",
    "instructions": "Toast bread and cook eggs, salt and pepper accordingly",
    "ingredients": "1tbs Salt\n2 Eggs\n1tbs Pepper\n2 slices Bread",
    "tags": [],
    "image": "https://lazy-cook-storage.s3.us-east-2.amazonaws.com/recipes/41.jpg"
  };

  fetch.mockResponseOnce(JSON.stringify({
    message: 'Displaying Saved Recipes',
    data: [item]
  }))

  component.root.instance.onFocusFunction()
});

test('SavedNavigator', async () => {
  const navigate = jest.fn();

  const providerProps = {
    userName: 'test1',
    userToken: "test",
    setUserName: () => { },
    setUserToken: () => { },
  }

  const component = renderer.create(<AuthContext.Provider value={providerProps}>
    <NavigationContainer>
      <SavedNavigator navigation={{ navigate }} username="test1" token="test1" />
    </NavigationContainer>
  </AuthContext.Provider>)
});