import React from "react";
import { View, ActivityIndicator } from "react-native";
import {
  NavigationContainer,
  DefaultTheme as NavigationDefaultTheme,
} from "@react-navigation/native";

import {
  Provider as PaperProvider,
  DefaultTheme as PaperDefaultTheme,
} from "react-native-paper";

import AuthContext from "./auth/context";
import AuthNavigator from "./navigation/AuthNavigator";
import AppNavigator from "./navigation/AppNavigator";
import authStorage from "./auth/storage";
import { navigationRef } from "./navigation/rootNavigation";

const theme = {
  ...NavigationDefaultTheme,
  ...PaperDefaultTheme,
  colors: {
    ...NavigationDefaultTheme.colors,
    ...PaperDefaultTheme.colors,
    background: "#ffffff",
    text: "#333333",
  },
};

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      userName: null,
      userToken: null,
    };

    this.loginReducer = this.loginReducer.bind(this);
    this.setUserToken = this.setUserToken.bind(this);
  }

  loginReducer(action) {
    switch (action.type) {
      case "RETRIEVE_TOKEN":
        this.setState({
          userToken: action.token,
          userName: action.name,
          isLoading: false,
        });
      // case "LOGIN":
      //   this.setState({
      //     userName: action.id,
      //     userToken: action.token,
      //     isLoading: false,
      //   });
      //   case "LOGOUT":
      //     this.setState({
      //       userName: null,
      //       userToken: null,
      //       isLoading: false,
      //     });
      //   case "REGISTER":
      //     this.setState({
      //       userName: action.id,
      //       userToken: action.token,
      //       isLoading: false,
      //     });
    }
  }

  componentDidMount() {
    setTimeout(async () => {
      // setIsLoading(false);
      let userToken = null;
      userToken = await authStorage.getUser("userToken");
      userName = await authStorage.getUser("userName");
      this.loginReducer({
        type: "RETRIEVE_TOKEN",
        token: userToken,
        name: userName,
      });
    }, 1000);
  }

  setUserToken = (userToken) => {
    this.setState((prevState) => ({ userToken }));
  };

  setUserName = (userName) => {
    this.setState((prevState) => ({ userName }));
  };

  render() {
    if (this.state.isLoading) {
      return (
        <View
          style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
          testID="loading"
        >
          <ActivityIndicator size="large" />
        </View>
      );
    }
    return (
      <AuthContext.Provider
        value={{
          userToken: this.state.userToken,
          setUserToken: this.setUserToken,
          userName: this.state.userName,
          setUserName: this.setUserName,
        }}
      >
        <PaperProvider theme={theme}>
          <NavigationContainer ref={navigationRef} theme={theme}>
            {this.state.userToken ? <AppNavigator /> : <AuthNavigator />}
          </NavigationContainer>
          <View testID="done"></View>
        </PaperProvider>
      </AuthContext.Provider>
    );
  }
}

export default App;
