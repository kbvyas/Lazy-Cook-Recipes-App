import React, { useState } from "react";
import {
  Button,
  StyleSheet,
  TouchableOpacity,
  View,
  Text,
  FlatList,
  ScrollView,
  TextInput,
  Alert,
} from "react-native";


import colors from "./config/colors";
import Screen from "./components/Screen";
import authStorage from "./auth/storage";
import AuthContext from "./auth/context";
import AppButton from "./components/AppButton";

class ProfileScreen extends React.Component {
  static contextType = AuthContext;
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
      email: "",
      vegetarian: false,
      vegan: false,
      glutenFree: false,
      lactoseIntolerance: false,
      token: "",
      disable: false,
    };
    this.componentDidMount = this.componentDidMount.bind(this);
    this.handleSave = this.handleSave.bind(this);
    this.handleLogout = this.handleLogout.bind(this);
    this.handleAlert = this.handleAlert.bind(this);
  }

  async componentDidMount() {
    const { userName, userToken } = this.context;
    let resp = await fetch(
      "https://lazy-cook.herokuapp.com/account/" + userName + "/",
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Token " + userToken,
        },
      }
    );
    let json = await resp.json();
    if (json.message === "success") {
      this.setState({
        username: userName,
        token: userToken,
        email: json.data.email,
        vegetarian: json.data.vegetarian,
        vegan: json.data.vegan,
        glutenFree: json.data.glutenFree,
        lactoseIntolerance: json.data.lactoseIntolerance,
      });
    } else if (json.detail === "invalid token") {
      alert("Session expired. Please re-login!")
      const { setUserToken, setUserName } = this.context;
      setUserToken(null);
      setUserName(null);
      authStorage.removeUser("userToken");
      authStorage.removeUser("userName");
    }
  }



  async handleSave() {
    this.setState({ disable: true })

    let body = undefined;
    if (this.state.password === "") {
      body = {
        username: this.state.username,
        vegetarian: this.state.vegetarian,
        vegan: this.state.vegan,
        glutenFree: this.state.glutenFree,
        lactoseIntolerance: this.state.lactoseIntolerance,
      };
    } else {
      body = {
        username: this.state.username,
        password: this.state.password,
        vegetarian: this.state.vegetarian,
        vegan: this.state.vegan,
        glutenFree: this.state.glutenFree,
        lactoseIntolerance: this.state.lactoseIntolerance,
      };
    }

    let resp = await fetch(
      "https://lazy-cook.herokuapp.com/account/" + this.state.username + "/",
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Token " + this.state.token,
        },
        body: JSON.stringify(body),
      }
    );

    let json = await resp.json();
    if (json.message === "update success") {
      alert("Successfully updating profile!");
    } else {
      alert(json.message);
    }

    this.setState({ disable: false })
  }

  handleLogout() {
    const { setUserToken, setUserName } = this.context;
    setUserToken(null);
    setUserName(null);
    authStorage.removeUser("userToken");
    authStorage.removeUser("userName");
  }

  handleAlert() {
    Alert.alert(
      "Log Out",
      "Are you sure you want to log out?",
      [{ text: "Yes", onPress: () => this.handleLogout() }, { text: "No" }],
      { cancelable: false }
    );
  }

  render() {
    return (
      <Screen>
        <View style={styles.topContainer}>
          <View style={styles.topContainerSmall}>
            <Text style={styles.text}>Profile</Text>
            <View style={styles.submitOut}>
              <AppButton
                name={"logout"}
                color={colors.medium}
                backcolor={colors.primary}
                size={50}
                onPress={() => this.handleAlert()}
              />
            </View>
          </View>
          <Text style={styles.subtext}>
            Please find your account infromation below
          </Text>
        </View>
        <ScrollView>
          <View style={styles.bottomContainer}>
            <View style={styles.containerBox}>
              <Text style={styles.title}>Account</Text>
              <View style={styles.fieldContainer}>
                <Text style={styles.fieldText}>Username:</Text>
                <TextInput
                  style={styles.field}
                  underlineColorAndroid="transparent"
                  placeholder={this.state.username}
                  placeholderTextColor="gray"
                  testID="username"
                  onChangeText={(username) =>
                    this.setState({ username: username })
                  }
                  value={this.state.username}
                  autoCapitalize="none"
                />
              </View>
              <View style={styles.fieldContainer}>
                <Text style={styles.fieldText}>Password:</Text>
                <TextInput
                  style={styles.field}
                  underlineColorAndroid="transparent"
                  placeholder="password"
                  placeholderTextColor="gray"
                  onChangeText={(password) =>
                    this.setState({ password: password })
                  }
                  value={this.state.password}
                  autoCapitalize="none"
                />
              </View>
              <View style={styles.fieldContainer}>
                <Text style={styles.fieldText0}>Email:</Text>
                <TextInput
                  style={styles.field}
                  underlineColorAndroid="transparent"
                  placeholder={this.state.email}
                  placeholderTextColor="gray"
                  testID="email"
                  onChangeText={(email) => this.setState({ email: email })}
                  value={this.state.email}
                  autoCapitalize="none"
                />
              </View>
              <View style={styles.separator} />
            </View>
            <View style={styles.separator} />
            <View style={styles.containerBox}>
              <Text style={styles.title}>Dietary Restrictions</Text>
              <Text style={styles.subtext2}>Please select all that apply</Text>
              <View style={styles.fieldContainer2}>
                <Text style={styles.fieldText2}>Vegetarian:</Text>
                <View style={styles.option} testID="vegetarian">
                  <TouchableOpacity
                    style={
                      this.state.vegetarian ? styles.buttonOn : styles.buttonOff
                    }
                    onPress={() =>
                      this.setState({ vegetarian: !this.state.vegetarian })
                    }
                  >
                    <Text
                      style={
                        this.state.vegetarian
                          ? styles.textCenterOn
                          : styles.textCenterOff
                      }
                    >
                      {this.state.vegetarian ? "Yes" : "No"}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.fieldContainer2}>
                <Text style={styles.fieldText2}>Vegan:</Text>
                <View style={styles.option} testID="vegan">
                  <TouchableOpacity
                    style={this.state.vegan ? styles.buttonOn : styles.buttonOff}
                    onPress={() => this.setState({ vegan: !this.state.vegan })}
                  >
                    <Text
                      style={
                        this.state.vegan
                          ? styles.textCenterOn
                          : styles.textCenterOff
                      }
                    >
                      {this.state.vegan ? "Yes" : "No"}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.fieldContainer2}>
                <Text style={styles.fieldText2}>GlutenFree:</Text>
                <View style={styles.option} testID="gluten-free">
                  <TouchableOpacity
                    style={
                      this.state.glutenFree ? styles.buttonOn : styles.buttonOff
                    }
                    onPress={() =>
                      this.setState({ glutenFree: !this.state.glutenFree })
                    }
                  >
                    <Text
                      style={
                        this.state.glutenFree
                          ? styles.textCenterOn
                          : styles.textCenterOff
                      }
                    >
                      {this.state.glutenFree ? "Yes" : "No"}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.fieldContainer2}>
                <Text style={styles.fieldText2}>Lactose Intolerant:</Text>
                <View style={styles.option} testID="lactose-intolerant">
                  <TouchableOpacity
                    style={
                      this.state.lactoseIntolerance
                        ? styles.buttonOn
                        : styles.buttonOff
                    }
                    onPress={() =>
                      this.setState({
                        lactoseIntolerance: !this.state.lactoseIntolerance,
                      })
                    }
                  >
                    <Text
                      style={
                        this.state.lactoseIntolerance
                          ? styles.textCenterOn
                          : styles.textCenterOff
                      }
                    >
                      {this.state.lactoseIntolerance ? "Yes" : "No"}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.separator} />
              <TouchableOpacity
                testID="submit-button"
                onPress={() => this.handleSave()}
                style={this.state.disable ? styles.submitDisabled : styles.submit}
                disabled={this.state.disable}
              >
                <Text style={styles.submitText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </Screen>
    );
  }
}

const styles = StyleSheet.create({
  backButton: {
    height: 30,
  },
  bottomContainer: {
    width: "100%",
    paddingHorizontal: 25,
    flex: 1,
  },
  button: {
    width: 70,
    right: 25,
    top: 25,
    position: "absolute",
  },
  buttonText: {
    color: "blue",
    fontFamily: "Arial",
    fontSize: 15,
  },
  containerBox: {
    marginHorizontal: 5,
  },
  field: {
    flex: 1,
    paddingHorizontal: 5,
  },
  fieldContainer: {
    width: "100%",
    borderBottomColor: colors.medium,
    borderBottomWidth: 1,
    flexDirection: "row",
    marginBottom: 10,
  },
  fieldContainer2: {
    flex: 1,
    width: "100%",
    flexDirection: "row",
    marginBottom: 0,
    height: 50,
    alignItems: "center",
    justifyContent: "space-between",
  },
  fieldText0: {
    padding: 5,
    width: 60,
  },
  fieldText: {
    padding: 5,
    width: 90,
  },
  fieldText2: {
    padding: 5,
  },
  navigator: {
    width: "100%",
    position: "absolute",
    bottom: -15,
    backgroundColor: colors.primary,
  },
  option: {
    width: 100,
  },
  separator: {
    width: "100%",
    height: 15,
  },
  subtext: {
    color: colors.medium,
    fontSize: 15,
    paddingLeft: 10,
  },
  subtext2: {
    color: colors.medium,
    fontSize: 15,
    paddingLeft: 5,
    marginVertical: 10,
    paddingBottom: 5,
  },
  submit: {
    width: "95%",
    height: 50,
    borderRadius: 20,
    backgroundColor: colors.green,
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
    marginTop: 10,
  },
  submitDisabled: {
    width: "95%",
    height: 50,
    borderRadius: 20,
    backgroundColor: "#ccc",
    color: "#999",
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
    marginTop: 10,
  },
  submitOut: {
    position: "absolute",
    right: 0,
    top: -15,
  },
  submitText: {
    fontSize: 15,
    fontFamily: "Arial",
    color: colors.white,
  },
  topContainer: {
    width: "100%",
    padding: 25,
  },
  topContainerSmall: {
    width: "100%",
    flexDirection: "row",
  },
  text: {
    color: colors.green,
    fontWeight: "800",
    fontSize: 25,
    fontFamily: "Arial",
    paddingLeft: 10,
    marginBottom: 20,
  },
  title: {
    color: colors.black,
    fontWeight: "800",
    fontSize: 25,
    fontFamily: "Arial",
    paddingLeft: 5,
    marginBottom: 10,
  },
  textCenterOn: {
    textAlign: "center",
    color: colors.white,
  },
  textCenterOff: {
    textAlign: "center",
    color: colors.green,
  },
  buttonOn: {
    backgroundColor: colors.green,
    borderRadius: 10,
    width: "100%",
  },
  buttonOff: {
    backgroundColor: colors.white,
    borderColor: colors.green,
    borderRadius: 10,
    width: "100%",
    borderWidth: 1,
  },
});
export default ProfileScreen;
