import React from "react";
import { Image, View, StyleSheet, TouchableOpacity } from "react-native";

import Icon from "./Icon";
import colors from "../config/colors";

function AppButton({ name, color, backcolor, size, onPress }) {
  return (
    <>
      <TouchableOpacity style={styles.container} onPress={onPress}>
        <Icon
          name={name}
          size={size}
          backgroundColor={backcolor}
          iconColor={color}
        />
      </TouchableOpacity>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: "center",
    alignItems: "center",
  },
});

export default AppButton;
