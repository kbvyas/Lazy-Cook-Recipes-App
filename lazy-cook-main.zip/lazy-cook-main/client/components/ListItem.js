import React from "react";
import { View, StyleSheet, Text, TouchableOpacity } from "react-native";
import colors from "../config/colors";

import Icon from "./Icon";

function ListItem({ label, onPress }) {
  return (
    <View style={styles.container}>
      <Text style={styles.listItem}>{label}</Text>
      <TouchableOpacity onPress={onPress}>
        <Icon
          name={"close"}
          backgroundColor={colors.primary}
          iconColor={colors.medium}
          size={20}
        />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    marginVertical: 10,
    alignItems: "center",
  },
});

export default ListItem;
