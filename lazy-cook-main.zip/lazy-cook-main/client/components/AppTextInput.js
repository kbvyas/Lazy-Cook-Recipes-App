import React from 'react';
import { Platform, TextInput, View, StyleSheet } from 'react-native';
import {MaterialCommunityIcons} from "@expo/vector-icons"

// import defaultStyles from "../config/styles";
import colors from '../config/colors';

function AppTextInput({text,...otherProps}) {
    return (
        <View style = {styles.container} testID="app-text-input">
            <TextInput style = {styles.text} {...otherProps}/>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        // backgroundColor: defaultStyles.colors.light,
        borderRadius: 25,
        flexDirection: "row",
        width: "100%",
        padding: 15,
        marginVertical: 10,
    },
    text: {
        fontSize: 20,
        //fontFamily: Roboto,
        color: colors.light,
    }
})

export default AppTextInput;