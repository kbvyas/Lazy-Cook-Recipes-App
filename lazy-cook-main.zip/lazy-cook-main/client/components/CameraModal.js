import React, { useState, useRef, useEffect } from "react";
import { View, StyleSheet, Text, Modal, TouchableOpacity, Dimensions, Platform } from "react-native";
import colors from "../config/colors";
import { Camera } from 'expo-camera';
import FontAwesome from "react-native-vector-icons/FontAwesome";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import * as ImagePicker from 'expo-image-picker';

let { width, height } = Dimensions.get('window')

function CameraModal({ cameraOn, setCameraOn, token, ingredientsFromCamera }) {
    const [type, setType] = useState(Camera.Constants.Type.back);
    const [flash, setFlash] = useState('off');

    let camera = useRef(null);

    let snap = async () => {
        if (camera) {
            let photo = await camera.takePictureAsync();
            setCameraOn(false)
            await sendImageToServer(photo.uri, "snap.jpg");
        }
    };

    useEffect(() => {
        (async () => {
            if (Platform.OS !== 'web') {
                const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
                if (status !== 'granted') {
                    alert('Sorry, we need camera roll permissions to make this work!');
                }
            }
        })();
    }, []);

    const pickImage = async () => {
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.All,
            allowsEditing: false,
            aspect: [4, 3],
            quality: 1,
        });

        if (!result.cancelled) {
            setCameraOn(false)
            await sendImageToServer(result.uri, "snap.jpg");
        }
    };

    const handleFlash = () => {
        if (flash === 'off') {
            setFlash('on')
        } else {
            setFlash('off')
        }
    }

    const sendImageToServer = async (uri, name) => {
        var data = new FormData();
        data.append('image', {
            uri: uri,
            name: name,
            type: 'image/jpg'
        })

        let resp = await fetch(
            "https://lazy-cook.herokuapp.com/api/picture-input/",
            {
                method: "POST",
                headers: {
                    "Content-Type": "multipart/form-data",
                    "Authorization": "Token " + token
                },
                body: data,
            }
        );

        let json = await resp.json()

        if (json.message === 'Successful predict ingredient') {
            ingredientsFromCamera(json.data, "Successfully recognizing ingredients")
        } else if (json.message === 'No ingredient predicted.Please try retake a photo or type in ingredients you have.') {
            ingredientsFromCamera(undefined, "Our model could not predict anything. Please try again using a different photo!")
        } else {
            ingredientsFromCamera(undefined, "Please contact our developer team to start the AutoML server!")
        }
    }

    return (
        <>
            <Modal
                animationType="slide"
                transparent={false}
                visible={cameraOn}
                fullScreen={true}
            >
                <Camera style={styles.camera} type={type} flashMode={flash} ref={ref => {
                    camera = ref;
                }}>
                </Camera>
                <View style={styles.bottom}>
                    <TouchableOpacity testID="picker-button" onPress={pickImage} style={styles.cameraButton}>
                        <Text style={styles.cameraButton}><FontAwesome name="image" color="white" size={width / 10} /></Text>
                    </TouchableOpacity>
                    <TouchableOpacity testID="snap-button" onPress={snap} style={styles.shutterButton}>
                        <Text style={styles.shutterButton}><FontAwesome name="circle-o" color="white" size={width / 6} /></Text>
                    </TouchableOpacity>
                    <TouchableOpacity testID="type-button" onPress={() => {
                        setType(
                            type === Camera.Constants.Type.back
                                ? Camera.Constants.Type.front
                                : Camera.Constants.Type.back
                        );
                    }} style={styles.cameraButton}>
                        <Text style={styles.cameraButton}><MaterialIcons name={Platform.OS === 'ios' ? "flip-camera-ios" : "flip-camera-android"} color="white" size={width / 10} /></Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.topRight}>
                    <TouchableOpacity testID="close-button-2" onPress={() => setCameraOn(!cameraOn)} style={styles.shutterButton}>
                        <Text style={styles.cameraButton}><MaterialIcons name="close" color="white" size={width / 12} /></Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.topLeft}>
                    <TouchableOpacity testID="flash-button" onPress={handleFlash} style={styles.shutterButton}>
                        <Text style={styles.cameraButton}><MaterialIcons name={flash === 'off' ? "flash-off" : "flash-on"} color="white" size={width / 12} /></Text>
                    </TouchableOpacity>
                </View>
            </Modal>
        </>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: colors.white,
        justifyContent: "center",
        alignItems: "center",
        marginHorizontal: 10,
    },
    camera: {
        flex: 1,
        width: width,
        height: height,
    },
    cameraButton: {
        fontSize: 30,
        color: 'white',
        flex: 1,
        textAlign: 'center',
    },
    shutterButton: {
        flex: 1,
        textAlign: 'center',
        marginVertical: -6,
    },
    bottom: {
        display: 'flex',
        justifyContent: "center",
        alignItems: "center",
        position: 'absolute',
        bottom: '3%',
        left: 0,
        right: 0,
        flexDirection: 'row',
    },
    topRight: {
        justifyContent: "center",
        alignItems: "center",
        position: 'absolute',
        top: "5%",
        right: "2%",
    },
    topLeft: {
        justifyContent: "center",
        alignItems: "center",
        position: 'absolute',
        top: "5%",
        left: "2%",
    }
});

export default CameraModal;
