import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  TextInput,
  Platform,
  LogBox,
} from "react-native";

import AppButton from "./components/AppButton";
import Screen from "./components/Screen";
import colors from "./config/colors";
import ListItem from "./components/ListItem";
import CameraModal from "./components/CameraModal";
import AuthContext from "./auth/context";
import navigation from "./navigation/rootNavigation";

import { Camera } from "expo-camera";
const methods = [
  {
    title: "camera",
    icon: {
      nameOn: "camera",
      backgroundColor: colors.green,
    },
  },
  // {
  //   title: "voice",
  //   icon: {
  //     nameOn: "microphone",
  //     backgroundColor: colors.green,
  //   },
  // },
];

class SearchByIngredientsScreen extends React.Component {
  static contextType = AuthContext;
  constructor(props) {
    super(props);
    this.state = {
      permission: false,
      cameraOn: false,
      text: "",
      ingredients: [],
      username: "",
      token: "",
    };

    this.handleDelete = this.handleDelete.bind(this);
    this.inputChange = this.inputChange.bind(this);
    this.handleInputButton = this.handleInputButton.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.setCameraOn = this.setCameraOn.bind(this);
    this.ingredientsFromCamera = this.ingredientsFromCamera.bind(this);
  }

  componentDidMount() {
    LogBox.ignoreLogs(["Can't perform a React state update on an unmounted component."]);
    const { userName, userToken } = this.context;
    this.setState({
      username: userName,
      token: userToken,
    });
  }
  handleDelete(ingredient) {
    this.setState({
      ingredients: this.state.ingredients.filter(
        (i) => i.ingredientsID !== ingredient.ingredientsID
      ),
    });
  }

  inputChange(val) {
    if (val.length !== 0) {
      let arr = val.split(",");
      let addedIngredients = [];
      for (let i = 0; i < arr.length; i++) {
        let curr = arr[i].trim().replace(/  +/g, ' ');
        if (this.state.ingredients.some((temp) => temp.label == curr)) {
          alert("Ingredient already added");
        } else {
          if (curr !== "") {
            addedIngredients.push({
              ingredientsID: this.state.ingredients.length + i + 1,
              label: curr,
            });
          }
        }
      }
      this.setState({
        ingredients: [...this.state.ingredients, ...addedIngredients],
        text: "",
      });
    }
  }

  async handleInputButton() {
    const { status } = await Camera.requestPermissionsAsync();
    //setHasPermission(status === 'granted');

    if (status === "granted") {
      this.setState({ cameraOn: true });
    }
  }

  async handleSubmit() {
    let ing = "";
    for (let i = 0; i < this.state.ingredients.length; i++) {
      ing += this.state.ingredients[i].label.replace(/ /g, "_");
      if (i != this.state.ingredients.length - 1) {
        ing += ",";
      }
    }
    this.props.navigation.navigate("SearchResultsScreen", {
      user: this.state.username,
      token: this.state.token,
      ingredients: ing,
    });
  }

  setCameraOn(val) {
    this.setState({
      cameraOn: val,
    });
  }

  ingredientsFromCamera(data, message) {
    if (data) {
      let index = this.state.ingredients.length + 1;
      let arr = [];
      for (let i = 0; i < data.length; i++) {
        let temp = data[i].replace(/_/g, ' ');
        arr.push({ ingredientsID: index, label: temp });
        index += 1;
      }
      this.setState({
        ingredients: [...this.state.ingredients, ...arr],
      });
    } else {
      alert(message);
    }
  }

  render() {
    return (
      <Screen>
        <View style={styles.container}>
          <View>
            <CameraModal
              cameraOn={this.state.cameraOn}
              setCameraOn={this.setCameraOn}
              token={this.state.token}
              ingredientsFromCamera={this.ingredientsFromCamera}
            />
          </View>
          <View style={styles.topContainer}>
            <Text style={styles.searchText}>Search by:</Text>
          </View>
          <View style={styles.selectContainer}>
            <View style={styles.select}>
              <View style={styles.action}>
                <TextInput
                  placeholder="Search by text or camera"
                  style={styles.textInput}
                  autoCapitalize="none"
                  onSubmitEditing={() => this.inputChange(this.state.text)}
                  onChangeText={(text) => this.setState({ text: text })}
                  value={this.state.text}
                />
                <FlatList
                  contentContainerStyle={styles.selectList}
                  data={methods}
                  keyExtractor={(method) => method.title}
                  horizontal={true}
                  testID="input-method"
                  renderItem={({ item }) => (
                    <AppButton
                      name={item.icon.nameOn}
                      size={40}
                      backcolor={"colors.white"}
                      color={item.icon.backgroundColor}
                      onPress={() => this.handleInputButton()}
                    />
                  )}
                />
              </View>
            </View>
          </View>
          <View style={styles.bottomContainer}>
            <View style={styles.container}>
              <Text style={styles.title}>Ingredients identified:</Text>
              <View style={styles.separator} />
              <View style={styles.listContainer} testID="ingredients">
                <FlatList
                  data={this.state.ingredients}
                  keyExtractor={(ingredient) => ingredient.label}
                  testID="ingredient-list"
                  renderItem={({ item }) => (
                    <ListItem
                      label={item.label}
                      onPress={() => this.handleDelete(item)}
                    />
                  )}
                />
              </View>
              <View style={styles.separator} />
            </View>
            <TouchableOpacity
              onPress={() => this.handleSubmit()}
              style={styles.submit}
              testID="submit"
            >
              <Text style={styles.submitText}>Proceed</Text>
            </TouchableOpacity>
            <Text style={styles.subtext}>
              The results will be adjusted based on your dietary preferences. This can be updated on your profile page.
            </Text>
          </View>
        </View>
      </Screen>
    );
  }
}

const styles = StyleSheet.create({
  action: {
    flexDirection: "row",
    borderColor: "black",
    borderWidth: 2,
    borderRadius: 7,
  },
  button: {
    borderColor: colors.green,
    borderWidth: 2,
    height: 50,
    width: 50,
  },
  bottomContainer: {
    flex: 1,
    marginTop: 10,
    flexGrow: 1,
    width: "100%",
    padding: 20,
    paddingHorizontal: 40,
  },
  container: {
    flex: 1,
    width: "100%",
    height: 300,
    justifyContent: "flex-start",
    marginBottom: 20,
  },
  listContainer: {
    flex: 1,
    width: "100%",
    height: 220,
  },
  listItem: {
    marginVertical: 5,
  },
  navigator: {
    width: "100%",
    position: "absolute",
    bottom: -15,
    backgroundColor: colors.primary,
  },
  selectContainer: {
    flex: 0.5,
    backgroundColor: colors.white,
    marginHorizontal: 10,
    borderRadius: 40,
    paddingHorizontal: 30,
    padding: 10,
  },
  select: {
    flex: 1,
    height: 150,
    width: "100%",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 10,
  },
  searchText: {
    color: colors.green,
    fontWeight: "800",
    fontSize: 25,
    fontFamily: "Arial",
  },
  selectList: {
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",
    flexDirection: "row",
    paddingRight: 5,
  },
  separator: {
    width: "100%",
    borderWidth: 1,
    borderColor: colors.medium,
  },
  submit: {
    width: "100%",
    height: 50,
    borderRadius: 20,
    backgroundColor: colors.green,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10,
  },
  submitText: {
    fontSize: 15,
    fontFamily: "Arial",
    color: colors.white,
  },
  subtext: {
    color: colors.medium,
    fontSize: 15,
    paddingLeft: 10,
    paddingTop: 15,
    textAlign: "center",
    fontStyle: "italic",
  },
  topContainer: {
    width: "100%",
    padding: 25,
    paddingBottom: 0,
    marginBottom: 10,
    flexDirection: "row",
    marginLeft: 10,
  },
  title: {
    height: 50,
    fontSize: 15,
    fontFamily: "Arial",
  },
  textInput: {
    marginTop: Platform.OS === "ios" ? 0 : -12,
    paddingHorizontal: 10,
    color: "#05375a",
    width: 225,
  },
});
export default SearchByIngredientsScreen;
