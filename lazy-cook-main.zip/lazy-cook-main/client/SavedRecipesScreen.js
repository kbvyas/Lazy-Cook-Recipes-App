import React, { useState } from "react";
import {
  Button,
  StyleSheet,
  TouchableOpacity,
  View,
  Text,
  FlatList,
} from "react-native";

import Card from "./components/Card";
import colors from "./config/colors";
import Screen from "./components/Screen";
import AuthContext from "./auth/context";
import navigation from "./navigation/rootNavigation";

class SavedRecipesScreen extends React.Component {
  static contextType = AuthContext;
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      token: "",
      recipes: [],
    };
    this.componentDidMount = this.componentDidMount.bind(this);
    this.onFocusFunction = this.onFocusFunction.bind(this);
  }
  async componentDidMount() {
    const { userName, userToken } = this.context;
    let resp = await fetch(
      "https://lazy-cook.herokuapp.com/account/" + userName + "/saved-recipe/",
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Token " + userToken,
        },
      }
    );
    let json = await resp.json();
    if (json.message === "Displaying Saved Recipes") {
      this.setState({
        username: userName,
        token: userToken,
        recipes: json.data,
      });
    }

    this.focusListener = this.props.navigation.addListener('focus', () => {
      this.onFocusFunction()
    })
  }

  async onFocusFunction() {
    const { userName, userToken } = this.context;
    let resp = await fetch(
      "https://lazy-cook.herokuapp.com/account/" + userName + "/saved-recipe/",
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Token " + userToken,
        },
      }
    );
    let json = await resp.json();
    if (json.message === "Displaying Saved Recipes") {
      if (JSON.stringify(json.data) !== JSON.stringify(this.state.recipes)) {
        this.setState({
          recipes: json.data,
        });
      }
    }
  }

  componentWillUnmount() {
    this.focusListener()
  }

  render() {
    return (
      <Screen>
        <View style={styles.topContainer}>
          <Text style={styles.text}>Saved Recipes</Text>
        </View>
        <View style={styles.bottomContainer}>
          <View style={styles.separator} />
          {this.state.recipes && this.state.recipes.length === 0 ? (
            <Text style={styles.notice}>No saved Recipes yet</Text>
          ) : (
            <FlatList
              data={this.state.recipes}
              keyExtractor={(recipe) => recipe.recipeID.toString()}
              testID="recipe-list"
              renderItem={({ item }) => (
                <Card
                  title={item.nameOfRecipe}
                  image={item.image}
                  key={item.recipeID}
                  onPress={() =>
                    navigation.navigate("SpecificRecipeScreen", {
                      prevScreen: "SavedRecipesScreen",
                      name: item.nameOfRecipe,
                      ingred: item.ingredients,
                      id: item.recipeID,
                      image: item.image,
                      step: item.instructions,
                      user: this.state.username,
                      token: this.state.token,
                    })
                  }
                />
              )}
            />
          )}
        </View>
      </Screen>
    );
  }
}

const styles = StyleSheet.create({
  backButton: {
    height: 30,
  },
  bottomContainer: {
    width: "100%",
    padding: 25,
    flex: 1,
  },
  button: {
    width: 70,
    right: 25,
    top: 25,
    position: "absolute",
  },
  buttonText: {
    color: "blue",
    fontFamily: "Arial",
    fontSize: 15,
  },
  navigator: {
    width: "100%",
    position: "absolute",
    bottom: -15,
    backgroundColor: colors.primary,
  },
  notice: {
    alignSelf: "center",
  },
  separator: {
    width: "100%",
    height: 10,
  },
  topContainer: {
    width: "100%",
    height: 80,
    padding: 25,
    flexDirection: "row",
  },
  text: {
    color: colors.green,
    fontWeight: "800",
    fontSize: 25,
    fontFamily: "Arial",
    paddingLeft: 10,
  },
});
export default SavedRecipesScreen;
