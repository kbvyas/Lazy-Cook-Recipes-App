import React from "react";

const AuthContext = React.createContext();

export default AuthContext;

// class AuthProvider extends Component {
//   constructor() {
//     this.state = {
//       userToken: null,
//     };
//   }

//   setUserToken = (userToken) => {
//     this.setState((prevState) => ({ userToken }));
//   };

//   render() {
//     const { children } = this.props;
//     const { userToken } = this.state;
//     const { setUserToken } = this;

//     return (
//       <AuthContext.Provider value={{ userToken, setUserToken }}>
//         {children}
//       </AuthContext.Provider>
//     );
//   }
// }

// export default AuthContext;

// export { AuthProvider };
