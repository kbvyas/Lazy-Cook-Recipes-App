//import * as SecureStore from "expo-secure-store";
import React from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

//const key = "userToken";

const storeUser = async (key, authToken) => {
  try {
    await AsyncStorage.setItem(key, authToken);
  } catch (error) {
    // console.log("error storing auth token", error);
  }
};

const getUser = async (key) => {
  try {
    const value = await AsyncStorage.getItem(key);
    return value;
  } catch (error) {
    // console.log("errror getting auth token", error);
    return null;
  }
};

const removeUser = async (key) => {
  try {
    await AsyncStorage.removeItem(key);
  } catch (error) {
    // console.log("error removing auth token", error);
  }
};

export default {
  getUser,
  removeUser,
  storeUser,
};
