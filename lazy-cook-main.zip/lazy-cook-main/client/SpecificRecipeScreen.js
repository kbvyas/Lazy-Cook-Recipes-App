import React, { useState } from "react";
import {
  Button,
  StyleSheet,
  TouchableOpacity,
  View,
  Text,
  ScrollView,
  Image,
  TextInput,
  Keyboard,
  Platform,
} from "react-native";
import StarRating from "react-native-star-rating";
import { KeyboardAccessoryView } from "react-native-keyboard-accessory";

import Card from "./components/Card";
import Icon from "./components/Icon";
import colors from "./config/colors";
import Screen from "./components/Screen";
import { FlatList } from "react-native-gesture-handler";
import { Colors } from "react-native/Libraries/NewAppScreen";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import Feather from "react-native-vector-icons/Feather";

import authStorage from "./auth/storage";
import AuthContext from "./auth/context";


class SearchResultsScreen extends React.Component {
  static contextType = AuthContext;
  constructor(props) {
    super(props);
    this.state = {
      reviews: [],
      average: 0,
      count: 0,
      review: "",
      rating: 1,
      saved: false,
      expandIngredients: true,
      expandInstructions: true,
      expandReviews: true,
      expandComment: true,
      expandAddReview: true,
    };

    this.componentDidMount = this.componentDidMount.bind(this);
    this.handleSubmitReview = this.handleSubmitReview.bind(this);
    this.handleSave = this.handleSave.bind(this);
  }

  async componentDidMount() {
    let resp = await fetch(
      "https://lazy-cook.herokuapp.com/api/recipe/" +
      this.props.route.params.id +
      "/ratings/",
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Token " + this.props.route.params.token,
        },
      }
    );
    let json = await resp.json();
    if (json.message === "Displaying Ratings for Recipe") {
      let total = 0;
      for (let i = 0; i < json.data.length; i++) {
        total += parseInt(json.data[i].ratingValue);
      }
      this.setState({
        reviews: json.data,
        average: json.data.length > 0 ? total / json.data.length : 0,
        count: json.data.length,
      });
    } else if (json.detail === "invalid token") {
      alert("Session expired. Please re-login!");
      const { setUserToken, setUserName } = this.context;
      setUserToken(null);
      setUserName(null);
      authStorage.removeUser("userToken");
      authStorage.removeUser("userName");
    }

    let resp2 = await fetch(
      "https://lazy-cook.herokuapp.com/account/" +
      this.props.route.params.user +
      "/saved-recipe/" +
      this.props.route.params.id +
      "/",
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Token " + this.props.route.params.token,
        },
      }
    );
    let json2 = await resp2.json();
    if (json2.message === "Displaying Saved Recipe") {
      this.setState({
        saved: true,
      });
    } else if (json2.message === "User has not saved this recipe") {
      this.setState({
        saved: false,
      });
    }
  }

  async handleSubmitReview() {
    let resp = await fetch(
      "https://lazy-cook.herokuapp.com/api/recipe/" +
      this.props.route.params.id +
      "/ratings/",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Token " + this.props.route.params.token,
        },
        body: JSON.stringify({
          ratingValue: this.state.rating,
          ratingDescription: this.state.review,
        }),
      }
    );
    let json = await resp.json();

    let cnt = this.state.count;
    if (json.message === "Made Rating for Recipe") {
      this.setState({
        reviews: [
          ...this.state.reviews,
          { ratingID: json.data, ratingValue: this.state.rating, ratingReview: this.state.review },
        ],
        average:
          (this.state.average * cnt + parseInt(this.state.rating)) / (cnt + 1),
        count: cnt + 1,
      });

      alert("Successfully adding a review!");
    } else if (json.detail === "invalid token") {
      alert("Session expired. Please re-login!");
      const { setUserToken, setUserName } = this.context;
      setUserToken(null);
      setUserName(null);
      authStorage.removeUser("userToken");
      authStorage.removeUser("userName");
    }

    this.setState({
      rating: 1,
      review: "",
    });
  }

  async handleSave() {
    if (this.state.saved == true) {
      let resp = await fetch(
        "https://lazy-cook.herokuapp.com/account/" +
        this.props.route.params.user +
        "/saved-recipe/" +
        this.props.route.params.id +
        "/",
        {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
            Authorization: "Token " + this.props.route.params.token,
          },
        }
      );
      if (resp.status === 204) {
        this.setState({
          saved: false,
        });
        alert("Successfully removed saved recipe!");
      } else {
        let json = await resp.json();
        if (json.detail === "invalid token") {
          alert("Session expired. Please re-login!");
          const { setUserToken, setUserName } = this.context;
          setUserToken(null);
          setUserName(null);
          authStorage.removeUser("userToken");
          authStorage.removeUser("userName");
        }
      }
    } else {
      let resp = await fetch(
        "https://lazy-cook.herokuapp.com/api/recipe/" +
        this.props.route.params.id +
        "/saved-recipe/",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: "Token " + this.props.route.params.token,
          },
        }
      );
      let json = await resp.json();
      if (json.message === "Recipe was successfully saved") {
        this.setState({
          saved: true,
        });
        alert("Successfully saved recipe!");
      } else if (json.detail === "invalid token") {
        alert("Session expired. Please re-login!");
        const { setUserToken, setUserName } = this.context;
        setUserToken(null);
        setUserName(null);
        authStorage.removeUser("userToken");
        authStorage.removeUser("userName");
      }
    }
  }

  render() {
    let reviews_list = [];

    this.state.reviews.forEach((item) => {
      reviews_list.push(
        <View style={styles.commentContainer} key={item.ratingID}>
          <View style={styles.starRatingContainer}>
            <StarRating
              disabled={true}
              maxStars={5}
              rating={parseInt(item.ratingValue)}
              halfStarEnabled={false}
              fullStarColor={colors.green}
              halfStarColor={colors.green}
              emptyStarColor={colors.green}
              starSize={20}
            />
          </View>
          <Text>{item.ratingReview}</Text>
        </View>
      );
    });

    return (
      <Screen>
        <View style={styles.topContainer}>
          <TouchableOpacity
            style={styles.backButton}
            testID="back-button"
            onPress={() =>
              this.props.route.params.prevScreen === "SearchResultsScreen"
                ? this.props.navigation.navigate("SearchResultsScreen", {
                  data: this.props.route.params.data,
                })
                : this.props.navigation.navigate("SavedRecipesScreen", {
                  user: this.props.route.params.user,
                  token: this.props.route.params.token,
                })
            }
          >
            <Feather name="arrow-left" color={colors.green} size={28} style={styles.backIcon} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.saveButton}
            testID="bookmark-button"
            onPress={() => this.handleSave()}
          >
            <Icon
              name={this.state.saved == true ? "bookmark" : "bookmark-outline"}
              size={45}
              backgroundColor={colors.primary}
              iconColor={colors.green}
            />
          </TouchableOpacity>
        </View>
        <ScrollView
          contentContainerStyle={{ paddingBottom: "60%", paddingTop: "0%" }}
        >
          <View style={styles.bottomContainer}>
            <Image
              style={styles.image}
              source={{ uri: this.props.route.params.image }}
            />
            <Text style={styles.title}>{this.props.route.params.name} </Text>
            <View style={styles.separator} />
            <View style={styles.ingredientsBox}>
              <View style={styles.stepsBoxFlex}>
                <Text style={styles.header}>Ingredients</Text>
                <View style={styles.expandLogo}>
                  <MaterialIcons
                    testID="expand-ingredients"
                    name={
                      this.state.expandIngredients
                        ? "expand-more"
                        : "expand-less"
                    }
                    color="black"
                    size={30}
                    onPress={() =>
                      this.setState({
                        expandIngredients: !this.state.expandIngredients,
                      })
                    }
                  />
                </View>
              </View>
              {this.state.expandIngredients ? (
                <Text style={styles.sub}>
                  {this.props.route.params.ingred.replace(/_/g, " ")}
                </Text>
              ) : (
                <></>
              )}
            </View>
            <View style={styles.separator} />
            <View style={styles.stepsBox}>
              <View style={styles.stepsBoxFlex}>
                <Text style={styles.header}>Instructions</Text>
                <View style={styles.expandLogo}>
                  <MaterialIcons
                    testID="expand-instructions"
                    name={
                      this.state.expandInstructions
                        ? "expand-more"
                        : "expand-less"
                    }
                    color="black"
                    size={30}
                    onPress={() =>
                      this.setState({
                        expandInstructions: !this.state.expandInstructions,
                      })
                    }
                  />
                </View>
              </View>
              {this.state.expandInstructions ? (
                <Text>{this.props.route.params.step}</Text>
              ) : (
                <></>
              )}
            </View>

            <View style={styles.separator} />
            <View style={styles.stepsBox}>
              <View style={styles.stepsBoxFlex}>
                <Text style={styles.header}>Reviews</Text>
                <View style={styles.expandLogo}>
                  <MaterialIcons
                    testID="expand-reviews"
                    name={
                      this.state.expandReviews ? "expand-more" : "expand-less"
                    }
                    color="black"
                    size={30}
                    onPress={() =>
                      this.setState({
                        expandReviews: !this.state.expandReviews,
                      })
                    }
                  />
                </View>
              </View>
              {this.state.expandReviews ? (
                <View style={styles.averageRatingContainer}>
                  <StarRating
                    disabled={true}
                    maxStars={5}
                    rating={this.state.average}
                    halfStarEnabled={true}
                    fullStarColor={colors.green}
                    halfStarColor={colors.green}
                    emptyStarColor={colors.green}
                    starSize={30}
                  />
                  <Text>Out of {this.state.count} ratings</Text>
                </View>
              ) : (
                <></>
              )}
            </View>

            <View style={styles.separator} />
            <View style={styles.stepsBox}>
              <View style={styles.stepsBoxFlex}>
                <Text style={styles.subheader}>Comments</Text>
                <View style={styles.expandLogo}>
                  <MaterialIcons
                    testID="expand-comment"
                    name={
                      this.state.expandComment ? "expand-more" : "expand-less"
                    }
                    color="black"
                    size={30}
                    onPress={() =>
                      this.setState({
                        expandComment: !this.state.expandComment,
                      })
                    }
                  />
                </View>
              </View>
              {this.state.expandComment ? reviews_list : <></>}
            </View>

            <View style={styles.separator} />
            <View style={styles.stepsBox}>
              <View style={styles.stepsBoxFlex}>
                <Text style={styles.subheader}>Add a Review</Text>
                <View style={styles.expandLogo}>
                  <MaterialIcons
                    testID="expand-review"
                    name={
                      this.state.expandAddReview
                        ? "expand-more"
                        : "expand-less"
                    }
                    color="black"
                    size={30}
                    onPress={() =>
                      this.setState({
                        expandAddReview: !this.state.expandAddReview,
                      })
                    }
                  />
                </View>
              </View>
              {this.state.expandAddReview ? (
                <View style={styles.stepsBox}>
                  <View>
                    <View style={styles.userRating} testID="star-rating">
                      <Text>Rating: </Text>
                      <StarRating
                        disabled={false}
                        maxStars={5}
                        rating={this.state.rating}
                        halfStarEnabled={false}
                        fullStarColor={colors.green}
                        halfStarColor={colors.green}
                        emptyStarColor={colors.green}
                        starSize={30}
                        selectedStar={(rating) =>
                          this.setState({ rating: rating })
                        }
                      />
                    </View>
                  </View>
                  <View style={styles.userRating}>
                    <TextInput
                      placeholder="Add your review here"
                      style={styles.textInput}
                      autoCapitalize="none"
                      onChangeText={(val) => this.setState({ review: val })}
                      value={this.state.review}
                      multiline={true}
                    />
                  </View>
                  <View style={styles.submitButtonContainer}>
                    <TouchableOpacity
                      style={styles.submitButton}
                      onPress={this.handleSubmitReview}
                      testID="submit-review"
                    >
                      <Text style={styles.submitButtonText}>
                        Submit Review
                        </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ) : (
                <></>
              )}
            </View>
          </View>
        </ScrollView>
      </Screen>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: "100%",
    justifyContent: "flex-start",
  },
  textInput: {
    flex: 1,
    marginTop: Platform.OS === "ios" ? 0 : -12,
    paddingLeft: 10,
    color: "#05375a",
    borderColor: colors.green,
    borderWidth: 1,
    borderRadius: 3,
    height: 100,
  },
  userRating: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    paddingBottom: "2%",
    paddingTop: "2%",
    marginTop: 3,
  },
  userRatingContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
  backButton: {
    left: 10,
    top: 15,
    position: "absolute",
  },
  backIcon: {
    paddingLeft: 12,
    paddingTop: 6
  },
  bottomContainer: {
    width: "100%",
    padding: 25,
    flex: 1,
  },
  submitButton: {
    backgroundColor: colors.green,
    borderRadius: 10,
    width: "40%",
    justifyContent: "center",
    alignItems: "center",
    padding: 10,
  },
  submitButtonText: {
    color: colors.white,
    fontWeight: "500",
  },
  submitButtonContainer: {
    alignItems: "center",
  },
  buttonText: {
    color: "blue",
    fontFamily: "Arial",
    fontSize: 15,
  },
  image: {
    borderColor: "black",
    borderWidth: 2,
    width: "100%",
    height: 300,
  },
  listBox: {
    width: "100%",
    height: 100,
    paddingTop: 5,
    borderWidth: 2,
    borderColor: "black",
    justifyContent: "space-evenly",
  },
  title: {
    color: colors.black,
    fontSize: 30,
    fontFamily: "Arial",
    fontWeight: "800",
    alignSelf: "center",
    margin: 10,
    textAlign: 'center',
  },
  saveButton: {
    right: 10,
    top: 15,
    position: "absolute",
  },
  separator: {
    width: "100%",
    height: "0.1%",
    marginVertical: "1%",
    backgroundColor: colors.gray,
  },
  topContainer: {
    width: "100%",
    minHeight: "7%",
    flexDirection: "row",
  },
  text: {
    color: colors.green,
    fontSize: 25,
    fontFamily: "Arial",
    paddingLeft: 10,
  },
  ingredientsBox: {
    width: "100%",
    paddingLeft: 5,
    flex: 1,
  },
  stepsBox: {
    width: "100%",
    paddingLeft: 5,
    flex: 1,
  },
  stepsBoxFlex: {
    width: "100%",
    flex: 1,
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  header: {
    fontWeight: "500",
    marginBottom: 10,
    fontSize: 22,
  },
  subheader: {
    fontWeight: "500",
    marginBottom: 10,
    fontSize: 18,
  },
  expandLogo: {
    marginBottom: 10,
  },
  averageRatingContainer: {
    width: "50%",
  },
  starRatingContainer: {
    width: "30%",
  },
  flatListStyle: {
    height: "50%",
  },
  commentContainer: {
    paddingBottom: "3%",
    paddingLeft: "5%",
  },
});
export default SearchResultsScreen;
