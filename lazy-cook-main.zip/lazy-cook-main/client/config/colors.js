export default {
    primary: "#F2F2F2",
    secondary: "#4ecdc4",
    black: "#000",
    white: "#fff",
    medium: "#6e6969",
    light: "#DFDFDF",
    dark: "#0c0c0c",
    green: "#025955",
    gray: "#cfc1c0",
}