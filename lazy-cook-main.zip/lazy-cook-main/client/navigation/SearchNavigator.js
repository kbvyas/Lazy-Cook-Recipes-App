import React from "react";

import { createStackNavigator } from "@react-navigation/stack";

import SearchByIngredientsScreen from "../SearchByIngredientsScreen";
import SearchResultsScreen from "../SearchResultsScreen";
import SpecificRecipeScreen from "../SpecificRecipeScreen";

const Stack = createStackNavigator();

class SearchNavigator extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <Stack.Navigator headerMode="none">
        <Stack.Screen
          name="SearchByIngredientsScreen"
          component={SearchByIngredientsScreen}
        />
        <Stack.Screen
          name="SearchResultsScreen"
          component={SearchResultsScreen}
        />
        <Stack.Screen
          name="SpecificRecipeScreen"
          component={SpecificRecipeScreen}
        />
      </Stack.Navigator>
    );
  }
}

export default SearchNavigator;
