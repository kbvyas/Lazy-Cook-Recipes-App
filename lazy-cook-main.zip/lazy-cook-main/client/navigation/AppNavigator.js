import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { StyleSheet, View } from "react-native";

import SearchNavigator from "./SearchNavigator";
import SavedNavigator from "./SavedNavigator";
import AddRecipeScreen from "../AddRecipeScreen";
import ProfileScreen from "../ProfileScreen";

import colors from "../config/colors";
const Tab = createBottomTabNavigator();

class AppNavigator extends React.Component {
  render() {
    return (
      <Tab.Navigator
        tabBarOptions={{
          showLabel: false,
          activeTintColor: colors.green,
          style: { height: 90 },
          iconStyle: { width: 100 },
        }}
      >
        <Tab.Screen
          name="Home"
          component={SearchNavigator}
          options={{
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="home" color={color} size={40} />
            ),
          }}
        />
        <Tab.Screen
          name="Saved"
          component={SavedNavigator}
          options={{
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="bookmark" color={color} size={40} />
            ),
          }}
        />
        <Tab.Screen
          name="Add"
          component={AddRecipeScreen}
          options={{
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="plus" color={color} size={40} />
            ),
          }}
        />
        <Tab.Screen
          name="Profile"
          component={ProfileScreen}
          options={{
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="account" color={color} size={40} />
            ),
          }}
        />
      </Tab.Navigator>
    );
  }
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: colors.white,
    width: 50,
    height: 100,
  },
});

export default AppNavigator;
