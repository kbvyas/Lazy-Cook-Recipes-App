import React from "react";

import { createStackNavigator } from "@react-navigation/stack";

import SpecificRecipeScreen from "../SpecificRecipeScreen";
import SavedRecipesScreen from "../SavedRecipesScreen";

const Stack = createStackNavigator();

class SavedNavigator extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <Stack.Navigator headerMode="none">
        <Stack.Screen
          name="SavedRecipesScreen"
          component={SavedRecipesScreen}
        />
        <Stack.Screen
          name="SpecificRecipeScreen"
          component={SpecificRecipeScreen}
        />
      </Stack.Navigator>
    );
  }
}

export default SavedNavigator;
