from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

from django.contrib.postgres.fields import ArrayField
# Create your models here.

class Ingredient(models.Model):
	ingredientID          = models.CharField(max_length = 10)  # The id we are associating with the ingredient
	ingredientDescription = models.CharField(max_length = 100) # The actual description of the item
	def __str__(self):
		return str(self.ingredientDescription)
	
class RecipeRating(models.Model):
	ratingID     = models.AutoField(primary_key=True)
	ratingValue  = models.IntegerField(default=1,validators=[MaxValueValidator(5), MinValueValidator(1)])
	ratingReview = models.TextField(default="")
	ratingAuthor = models.CharField(default="",max_length = 100)
	recipeReview = models.ForeignKey('Recipe',blank=True,null=True,on_delete=models.CASCADE)

class Recipe(models.Model):
	recipeID                     = models.AutoField(primary_key=True)
	recipeAuthor                 = models.CharField(default="",max_length = 100)
	dateCreatedOn                = models.DateTimeField(auto_now_add = True)
	nameOfRecipe                 = models.CharField(max_length = 100)
	recipeIngredients 	     = models.ManyToManyField(Ingredient)
	recipeIngredientsDescription = models.TextField(default="")
	instructions                 = models.TextField()
	tags                         = ArrayField(models.CharField(max_length=30,blank=True),size=3,default=None)
	image                        = models.ImageField(blank=True, upload_to='recipeImages/')
	#recipeReview 		     = models.ForeignKey(RecipeRating,blank=True,null=True,on_delete=models.CASCADE)



	

