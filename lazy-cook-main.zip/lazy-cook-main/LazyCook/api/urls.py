from django.urls import path,include
from .views import RecipeView, PictureInput, RecipeRatingViewset, UploadView
from rest_framework_nested.routers import DefaultRouter, NestedDefaultRouter

#https://github.com/alanjds/drf-nested-routers

router = DefaultRouter()

router.register(r'recipe', RecipeView, basename='recipe')
router.register(r'picture-input', PictureInput,basename = "picture-input")
router.register(r'upload', UploadView, basename='upload')

recipe_router = NestedDefaultRouter(router,r'recipe',lookup='recipeID')
recipe_router.register(r'ratings',RecipeRatingViewset,basename='recipe-ratings')

urlpatterns = [
	path('',include(router.urls)),
	path('',include(recipe_router.urls))

]