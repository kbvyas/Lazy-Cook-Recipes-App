import logging
import boto3
from botocore.exceptions import ClientError

S3_BUCKET_NAME = "lazy-cook-storage"
RECIPE_FOLDER = 'recipes/'

# Example:
# upload_file('bacon.jpg')
def upload_file(file_name, bucket=S3_BUCKET_NAME, object_name=None):
    if object_name is None:
        object_name = f"{RECIPE_FOLDER}{file_name}"

    s3_client = boto3.client('s3')
    try:
        response = s3_client.upload_file(file_name, bucket, object_name, ExtraArgs={'ContentType': "image/jpeg", 'ACL': "public-read"})
    except ClientError as e:
        logging.error(e)
        return False
    return True

# Example:
# download_file('./bacon.jpg', 'recipes/bacon.jpg')
def download_file(path, object_name, bucket=S3_BUCKET_NAME):
    s3.download_file(bucket, object_name, path)