from django.test import TestCase
from rest_framework.test import APITestCase
from rest_framework import status
from .models import Recipe
from django.contrib.auth.models import User
from django.http import HttpResponsePermanentRedirect
# Create your tests here.

class RecipeTestCase(APITestCase):

	def setUp(self):
        	user = User.objects.create_user(username='admin1')
        	user.set_password('admin')
        	user.account.email = 'admin@gmail.com'
        	user.account.isAdmin = True
        	user.save()
        	res = self.client.post('/login', {'username': 'admin1', 'password': 'admin'}, format='json')
        	self.token = res.data.get('token', None)
        	self.assertIsNotNone(self.token, "Failed to setup test case")

	def test_create_recipe(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

	def test_create_recipe_name_recipe_empty(self):

		recipe = {
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST, msg = response.data.get('message', response.data.get('detail',None)))

	def test_create_recipe_instructions_recipe_empty(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST, msg = response.data.get('message', response.data.get('detail',None)))

	def test_ingredients_not_empty(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST,msg = response.data.get('message', response.data.get('detail',None)))

	def test_amount_of_ingredients_not_empty(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes"}, 
              				 {"ingredient":"Chicken"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST,msg = response.data.get('message', response.data.get('detail',None)))

	def test_length_of_amount_and_number_ingredients_match(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST,msg = response.data.get('message', response.data.get('detail',None)))

	def test_non_allowed_tags_rejected(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["gluten"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST,msg = response.data.get('message', response.data.get('detail',None)))

	def test_multiple_allowed_tags_accepted(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan","vegetarian"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED,msg = response.data.get('message', response.data.get('detail',None)))

	def test_too_many_tags_rejected(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan","vegetarian","vegetarian","vegan","vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST,msg = response.data.get('message', response.data.get('detail',None)))

	def test_find_all_recipes(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		
		recipe["nameOfRecipe"] = "broccoli casserole"
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		response = self.client.get('/api/recipe/',format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK,msg = response.data.get('message', response.data.get('detail',None)))
		self.assertEqual(len(response.data['data']),2)
		
	def test_find_recipes_by_recipe_name(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		
		recipeName = {"RecipeKeywords":"broccoli"}
		response = self.client.get('/api/recipe/',recipeName,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK,msg = response.data.get('message', response.data.get('detail',None)))
		self.assertEqual(len(response.data['data']),1)
		
		recipeName = {"RecipeKeywords":"Nothing"}
		response = self.client.get('/api/recipe/',recipeName,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK,msg = response.data.get('message', response.data.get('detail',None)))
		self.assertEqual(len(response.data['data']),0)

	def test_get_individual_recipes(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		data = response.data['data']
		self.assertEqual(data['nameOfRecipe'],'broccoli')
		incorrectRecipeID = recipeID+1
		response = self.client.get(f'/api/recipe/{incorrectRecipeID}/',format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)

	def test_update_individual_recipes(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updatedRecipe = {"nameOfRecipe":"broccoli casserole",
			  "instructions":"Cook the food well",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegetarian"],
			  }
		response = self.client.put(f'/api/recipe/{recipeID}/',updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)
		
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		data = response.data['data']
		self.assertEqual(data['nameOfRecipe'],'broccoli casserole')
		self.assertEqual(data['instructions'],'Cook the food well')
		self.assertEqual(data['tags'][0],'vegetarian')

	def test_patch_name_recipes(self):

		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updateRecipeParts = {"nameOfRecipe":"broccoli casserole"}
				
		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)	

		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		data = response.data['data']	
		self.assertEqual(data['nameOfRecipe'],'broccoli casserole')

	def test_patch_author_recipes(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updateRecipeParts = {"recipeAuthor":"newUser"}
				     
		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)	
	
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		data = response.data['data']
		self.assertEqual(data['recipeAuthor'],'admin1')
		
	def test_patch_instructions_recipes(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updateRecipeParts = {"instructions":"Cook the food well"}
				     
		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)	

		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		data = response.data['data']	
		self.assertEqual(data['instructions'],'Cook the food well')
		
	def test_patch_tags_recipes(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updateRecipeParts = {"tags":["vegetarian"]}

		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)	
		
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		data = response.data['data']
		self.assertEqual(data['tags'][0],'vegetarian')

	def test_delete_recipes(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)
		
		response = self.client.delete(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_204_NO_CONTENT)
		
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)

	def test_put_unauthorized_recipes(self):
		user = User.objects.create_user(username='admin2')
		user.set_password('admin')
		user.account.email = 'admin2@gmail.com'
		user.account.isAdmin = False
		user.save()		
		res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
		self.token_2 = res.data.get('token', None)
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']
		
		updatedRecipe = {"nameOfRecipe":"broccoli casserole",
			  "instructions":"Cook the food well",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegetarian"],
			  }
		response = self.client.patch(f'/api/recipe/{recipeID}/',updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
		self.assertEqual(response.status_code,status.HTTP_403_FORBIDDEN)

	def test_patch_unauthorized_recipes(self):
		user = User.objects.create_user(username='admin2')
		user.set_password('admin')
		user.account.email = 'admin2@gmail.com'
		user.account.isAdmin = False
		user.save()		
		res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
		self.token_2 = res.data.get('token', None)
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']
		
		updateRecipeParts = {"nameOfRecipe":"broccoli casserole"}
		response = self.client.put(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
		self.assertEqual(response.status_code,status.HTTP_403_FORBIDDEN)

	def test_patch_admin_authorized_recipes(self):
		user = User.objects.create_user(username='admin2')
		user.set_password('admin')
		user.account.email = 'admin2@gmail.com'
		user.account.isAdmin = True
		user.save()		
		res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
		self.token_2 = res.data.get('token', None)
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']
		
		updateRecipeParts = {"nameOfRecipe":"broccoli casserole"}
		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

	def test_put_admin_authorized_recipes(self):
		user = User.objects.create_user(username='admin2')
		user.set_password('admin')
		user.account.email = 'admin2@gmail.com'
		user.account.isAdmin = True
		user.save()		
		res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
		self.token_2 = res.data.get('token', None)
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']
		
		updatedRecipe = {"nameOfRecipe":"broccoli casserole",
			  "instructions":"Cook the food well",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegetarian"],
			  }
		response = self.client.put(f'/api/recipe/{recipeID}/', updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

	def test_not_admin_or_user_unauthorized_put_recipes(self):
		user = User.objects.create_user(username='admin2')
		user.set_password('admin')
		user.account.email = 'admin2@gmail.com'
		user.account.isAdmin = False
		user.save()		
		res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
		self.token_2 = res.data.get('token', None)
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']
		
		updatedRecipe = {"nameOfRecipe":"broccoli casserole",
			  "instructions":"Cook the food well",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegetarian"],
			  }
		response = self.client.put(f'/api/recipe/{recipeID}/', updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
		self.assertEqual(response.status_code,status.HTTP_403_FORBIDDEN)

	def test_put_recipes_does_not_exist(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']+1
		
		updatedRecipe = {"nameOfRecipe":"broccoli casserole",
			  "instructions":"Cook the food well",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegetarian"],
			  }
		response = self.client.put(f'/api/recipe/{recipeID}/', updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)

	def test_put_recipes_recipe_name_missing(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']
		
		updatedRecipe = {
			  "instructions":"Cook the food well",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegetarian"],
			  }
		response = self.client.put(f'/api/recipe/{recipeID}/', updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST)

	def test_put_recipes_recipe_instructions_missing(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']
		
		updatedRecipe = {"nameOfRecipe":"broccoli",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegetarian"],
			  }
		response = self.client.put(f'/api/recipe/{recipeID}/', updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST)

	def test_put_recipes_recipe_ingredients_missing(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']
		
		updatedRecipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[],
			  "tags":["vegan"],
			  }
		response = self.client.put(f'/api/recipe/{recipeID}/', updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST)

	def test_put_recipes_recipe_ingredients_missing_amounts(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']
		
		updatedRecipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken"}],
			  "tags":["vegan"],
			  }
		response = self.client.put(f'/api/recipe/{recipeID}/', updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST)

	def test_put_recipes_recipe_bad_tag(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipeID = response.data['data']
		
		updatedRecipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["invalid tag"],
			  }
		response = self.client.put(f'/api/recipe/{recipeID}/', updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST)

	def test_update_individual_recipes_with_new_ingredient(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updatedRecipe = {"nameOfRecipe":"broccoli casserole",
			  "instructions":"Cook the food well",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Tomato","amount": "1lbs"}],
			  "tags":["vegetarian"],
			  }
		response = self.client.put(f'/api/recipe/{recipeID}/',updatedRecipe,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)
		
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		data = response.data['data']
		self.assertEqual(data['nameOfRecipe'],'broccoli casserole')
		self.assertEqual(data['instructions'],'Cook the food well')
		self.assertEqual(data['tags'][0],'vegetarian')

	def test_patch_recipe_does_not_exist(self):

		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updateRecipeParts = {"nameOfRecipe":"broccoli casserole"}
		recipeID += 1	
		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)

	def test_patch_recipe_image(self):

		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updateRecipeParts = {"image":"aPicture.png"}
		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

	def test_patch_recipe_invalid_tag(self):

		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updateRecipeParts = {"tags":["invalid tag"]}
		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST)

	def test_patch_recipe_ingredients(self):

		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updateRecipeParts = {"recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}]}
		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

	def test_patch_recipe_new_ingredients(self):

		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updateRecipeParts = {"recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Cucumber","amount": "1lbs"}]}
		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

	def test_patch_recipe_new_ingredients_missing_amounts(self):

		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.get(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK)

		updateRecipeParts = {"recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Cucumber"}]}
		response = self.client.patch(f'/api/recipe/{recipeID}/',updateRecipeParts,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST)

	def test_delete_recipes_does_not_exist(self):
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']+1
		response = self.client.delete(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)

	def test_delete_recipes_not_authorized(self):
		user = User.objects.create_user(username='admin2')
		user.set_password('admin')
		user.account.email = 'admin2@gmail.com'
		user.account.isAdmin = False
		user.save()		
		res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
		self.token_2 = res.data.get('token', None)
		recipe = {"nameOfRecipe":"broccoli",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
              				 {"ingredient":"Chicken","amount": "1lbs"}],
			  "tags":["vegan"],
			  }

		response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipeID = response.data['data']
		response = self.client.delete(f'/api/recipe/{recipeID}/',format = 'json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
		self.assertEqual(response.status_code,status.HTTP_403_FORBIDDEN)
	
	#RECIPE SEARCH TESTS
	#Test it returns only the first recipe
	def test_return_1(self):
		recipe1 = {"nameOfRecipe":"Simple toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"}],
							   "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe1, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipe2 = {"nameOfRecipe":"Better toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"},{"ingredient":"Salt","amount": "1tbps"},
							 {"ingredient":"Pepper","amount": "1tbps"}],
							 "tags":["vegan"],
			  } 
		response = self.client.post('/api/recipe/',recipe2, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		
		recipeName = {"Ingredients":"Eggs,Bread"}
		response = self.client.get('/api/recipe/',recipeName,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK,msg = response.data.get('message', response.data.get('detail',None)))
		self.assertEqual(len(response.data['data']),1)

	#Test it returns multiple recipes containing the ingredients listed
	def test_return_2(self):
		recipe1 = {"nameOfRecipe":"Simple toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"}],
							   "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe1, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipe2 = {"nameOfRecipe":"Better toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"},{"ingredient":"Salt","amount": "1tbps"},
							 {"ingredient":"Pepper","amount": "1tbps"}],
							 "tags":["vegan"],
			  } 
		response = self.client.post('/api/recipe/',recipe2, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		
		recipeName = {"Ingredients":"Eggs,Bread,Salt,Pepper"}
		response = self.client.get('/api/recipe/',recipeName,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK,msg = response.data.get('message', response.data.get('detail',None)))
		self.assertEqual(len(response.data['data']),2)

	#Test case doesnt matter when returning recipe
	def test_return_3(self):
		recipe1 = {"nameOfRecipe":"Simple toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"}],
							   "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe1, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipe2 = {"nameOfRecipe":"Better toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"},{"ingredient":"Salt","amount": "1tbps"},
							 {"ingredient":"Pepper","amount": "1tbps"}],
							 "tags":["vegan"],
			  } 
		response = self.client.post('/api/recipe/',recipe2, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		
		recipeName = {"Ingredients":"eGGs,BrEad,salt,PEPPER"}
		response = self.client.get('/api/recipe/',recipeName,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK,msg = response.data.get('message', response.data.get('detail',None)))
		self.assertEqual(len(response.data['data']),2)

	#Test order doesnt matter when returning recipe
	def test_return_4(self):
		recipe1 = {"nameOfRecipe":"Simple toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"}],
							   "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe1, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipe2 = {"nameOfRecipe":"Better toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"},{"ingredient":"Salt","amount": "1tbps"},
							 {"ingredient":"Pepper","amount": "1tbps"}],
							 "tags":["vegan"],
			  } 
		response = self.client.post('/api/recipe/',recipe2, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		
		recipeName = {"Ingredients":"Bread,Eggs"}
		response = self.client.get('/api/recipe/',recipeName,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK,msg = response.data.get('message', response.data.get('detail',None)))
		self.assertEqual(len(response.data['data']),1)

	#Test it returns the recipes containing different worded ingredients entered by user than in the recipe's
	def test_return_5(self):
		recipe1 = {"nameOfRecipe":"Simple toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"}],
							   "tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe1, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
		recipe2 = {"nameOfRecipe":"Better toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"},{"ingredient":"Salt","amount": "1tbps"},
							 {"ingredient":"Pepper","amount": "1tbps"}],
							 "tags":["vegan"],
			  } 
		response = self.client.post('/api/recipe/',recipe2, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		
		recipeName = {"Ingredients":"Eggs,whole grain Bread,Rock Salt,Pepper"}
		response = self.client.get('/api/recipe/',recipeName,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK,msg = response.data.get('message', response.data.get('detail',None)))
		self.assertEqual(len(response.data['data']),2)

	#Test it returns recipes even without some ingredients entered by user
	def test_return_6(self):
		recipe1 = {"nameOfRecipe":"Simple toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"}],
							"tags":["vegan"],
			  }
		response = self.client.post('/api/recipe/',recipe1, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		recipe2 = {"nameOfRecipe":"Better toast and eggs",
			  "recipeAuthor":"admin1",
			  "instructions":"Cook the food",
			  "recipeIngredients":[{"ingredient":"Bread","amount": "1 slice"}, 
              				 {"ingredient":"Eggs","amount": "1"},{"ingredient":"Salt","amount": "1tbps"},
							 {"ingredient":"Pepper","amount": "1tbps"}],
							 "tags":["vegan"],
			  } 
		response = self.client.post('/api/recipe/',recipe2, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

		
		recipeName = {"Ingredients":"Eggs,milk,bread,salt,salmon,pepper"}

		response = self.client.get('/api/recipe/',recipeName,format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
		self.assertEqual(response.status_code,status.HTTP_200_OK,msg = response.data.get('message', response.data.get('detail',None)))
		self.assertEqual(len(response.data['data']),2)


class RatingTestCase(APITestCase):
        def setUp(self):
                user = User.objects.create_user(username='admin1')
                user.set_password('admin')
                user.account.email = 'admin@gmail.com'
                user.account.isAdmin = True
                user.save()
                res = self.client.post('/login', {'username': 'admin1', 'password': 'admin'}, format='json')
                self.token = res.data.get('token', None)
                self.assertIsNotNone(self.token, "Failed to setup test case")
                recipe = {"nameOfRecipe":"broccoli",
              "recipeAuthor":"admin1",
              "instructions":"Cook the food",
              "recipeIngredients":[{"ingredient":"Russet Potatoes","amount": "1lbs"}, 
                             {"ingredient":"Chicken","amount": "1lbs"}],
              "tags":["vegan"],
              }

                response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
                self.recipeID = response.data['data']

                rating = {"ratingValue":4,
              "ratingDescription":"This is certainly food"
              }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
                self.ratingID = response.data['data']

        def test_get_ratings_individual_rating_not_found(self):
                ratingID = self.ratingID + 1
                response = self.client.get(f'/api/recipe/{self.recipeID}/ratings/{ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND, msg = response.data.get('message', response.data.get('detail',None)))
                        
        def test_create_rating(self):
                rating = {"ratingValue":3,
                          "ratingDescription":"This is certainly food"
                          }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

        def test_create_invalid_rating_value_out_of_range(self):
                rating = {"ratingValue":14,
                          "ratingDescription":"This is certainly food"
                          }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST, msg = response.data.get('message', response.data.get('detail',None)))

        def test_create_rating_recipe_missing(self):
                recipeID = self.recipeID + 1
                rating = {"ratingValue":4,
                  "ratingDescription":"This is certainly food"
                  }

                response = self.client.post(f'/api/recipe/{recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND, msg = response.data.get('message', response.data.get('detail',None)))

        def test_create_rating_value_missing(self):
                rating = {
                          "ratingDescription":"This is certainly food"
                          }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST, msg = response.data.get('message', response.data.get('detail',None)))

        def test_get_ratings(self):
                rating = { "ratingValue":4,
                "ratingDescription":"This is certainly food"
                                         }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')

                response = self.client.get(f'/api/recipe/{self.recipeID}/ratings/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
                self.assertEqual(2,len(response.data['data']))
                        
        def test_get_ratings_missing_recipe(self):
                recipeID = self.recipeID + 1
                response = self.client.get(f'/api/recipe/{recipeID}/ratings/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND, msg = response.data.get('message', response.data.get('detail',None)))

        def test_get_ratings_individual_rating(self):
                rating = { "ratingValue":14,
                "ratingDescription":"This is certainly food"
                                         }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')

                response = self.client.get(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))

        def test_get_ratings_individual_rating_missing(self):
                rating = { "ratingValue":4,
                "ratingDescription":"This is certainly food"
                                         }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                ratingID = response.data['data']+1
                response = self.client.get(f'/api/recipe/{self.recipeID}/ratings/{ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND, msg = response.data.get('message', response.data.get('detail',None)))
                        
        def test_update_recipe(self):
                rating = { "ratingValue":3,
                "ratingDescription":"This is certainly food I would say"
                                         }

                response = self.client.put(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
                
                response = self.client.get(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
                self.assertEqual(response.data['data']['ratingValue'],3)
                self.assertEqual(response.data['data']['ratingReview'],"This is certainly food I would say")
                        
        def test_update_recipe_missing_value(self):
                rating = {
                "ratingDescription":"This is certainly food"
                                         }

                response = self.client.put(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST, msg = response.data.get('message', response.data.get('detail',None)))
                
                response = self.client.get(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
                self.assertEqual(response.data['data']['ratingValue'],4)
                        
        def test_update_recipe_missing_recipe(self):
                recipeID = self.recipeID +1
                rating = {"ratingValue":3,
                                "ratingDescription":"This is certainly food"
                                 }

                response = self.client.put(f'/api/recipe/{recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND, msg = response.data.get('message', response.data.get('detail',None)))

        def test_put_individual_ratings_missing(self):
                rating = { "ratingValue":2,
                "ratingDescription":"This is certainly food"
                                         }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                ratingID = response.data['data']+1
                rating = {"ratingValue":3,
                                        "ratingDescription":"This is certainly food most likely"
                                         }
                response = self.client.put(f'/api/recipe/{self.recipeID}/ratings/{ratingID}/', rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND, msg = response.data.get('message', response.data.get('detail',None)))
                        
        def test_update_recipe_unauthorized_person(self):

                user = User.objects.create_user(username='admin2')
                user.set_password('admin')
                user.account.email = 'admin2@gmail.com'
                user.account.isAdmin = False
                user.save()		
                res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
                self.token_2 = res.data.get('token', None)

                rating = {"ratingValue":3,
        "ratingDescription":"This is certainly food"
                                 }

                response = self.client.put(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
                self.assertEqual(response.status_code,status.HTTP_403_FORBIDDEN, msg = response.data.get('message', response.data.get('detail',None)))
                        
        def test_update_recipe_authorized_person_admin(self):

                user = User.objects.create_user(username='admin2')
                user.set_password('admin')
                user.account.email = 'admin2@gmail.com'
                user.account.isAdmin = True
                user.save()		
                res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
                self.token_2 = res.data.get('token', None)

                rating = {"ratingValue":4,
        "ratingDescription":"This is certainly food"
                                 }

                response = self.client.put(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))

        def test_patch_recipe_authorized_person_admin(self):

                user = User.objects.create_user(username='admin2')
                user.set_password('admin')
                user.account.email = 'admin2@gmail.com'
                user.account.isAdmin = True
                user.save()		
                res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
                self.token_2 = res.data.get('token', None)

                rating = {"ratingValue":4,
                                 }

                response = self.client.patch(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))

        def test_patch_recipe_unauthorized_person(self):

                user = User.objects.create_user(username='admin2')
                user.set_password('admin')
                user.account.email = 'admin2@gmail.com'
                user.account.isAdmin = False
                user.save()		
                res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
                self.token_2 = res.data.get('token', None)

                rating = {"ratingValue":3,
                                 }

                response = self.client.patch(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
                self.assertEqual(response.status_code,status.HTTP_403_FORBIDDEN, msg = response.data.get('message', response.data.get('detail',None)))
                        
        def test_patch_recipe_rating_value(self):

                rating = {"ratingValue":3,
                                         }

                response = self.client.patch(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
                
                response = self.client.get(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
                self.assertEqual(response.data['data']['ratingValue'],3)
                        
        def test_patch_recipe_invalid_rating_value(self):

                rating = {"ratingValue":22,
                                         }

                response = self.client.patch(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_400_BAD_REQUEST, msg = response.data.get('message', response.data.get('detail',None)))

        def test_patch_recipe_rating_description(self):

                rating = {"ratingDescription":"This is certainly food most likely"
                                         }

                response = self.client.patch(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
                
                response = self.client.get(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
                self.assertEqual(response.data['data']['ratingReview'],"This is certainly food most likely")

        def test_patch_recipe_both(self):

                rating = {"ratingValue":3,
                                        "ratingDescription":"This is certainly food most likely"
                                         }

                response = self.client.patch(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
                
                response = self.client.get(f'/api/recipe/{self.recipeID}/ratings/{self.ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
                self.assertEqual(response.data['data']['ratingValue'],3)
                self.assertEqual(response.data['data']['ratingReview'],"This is certainly food most likely")
                        
        def test_patch_ratings_missing_recipe(self):
                rating = {"ratingValue":3,
                                "ratingDescription":"This is certainly food most likely"
                                 }
                recipeID = self.recipeID + 1
                response = self.client.patch(f'/api/recipe/{recipeID}/ratings/{self.ratingID}/', rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND, msg = response.data.get('message', response.data.get('detail',None)))
                                
        def test_patch_individual_ratings_missing(self):
                rating = { "ratingValue":3,
                "ratingDescription":"This is certainly food"
                                         }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                ratingID = response.data['data']+1
                rating = {"ratingValue":4,
                                        "ratingDescription":"This is certainly food most likely"
                                         }
                response = self.client.patch(f'/api/recipe/{self.recipeID}/ratings/{ratingID}/', rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND, msg = response.data.get('message', response.data.get('detail',None)))
                        
        def test_delete_rating(self):

                rating = {"ratingValue":4,
                                        "ratingDescription":"This is certainly food most likely"
                                         }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
                ratingID = response.data['data']
                
                response = self.client.delete(f'/api/recipe/{self.recipeID}/ratings/{ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_204_NO_CONTENT)
                
                response = self.client.delete(f'/api/recipe/{self.recipeID}/ratings/{ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)

        def test_delete_rating_not_found(self):
                ratingID = self.ratingID + 1
        
                response = self.client.delete(f'/api/recipe/{self.recipeID}/ratings/{ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)

        def test_delete_recipe_not_found(self):
                recipeID = self.recipeID + 1
        
                response = self.client.delete(f'/api/recipe/{recipeID}/ratings/{self.ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)

        def test_delete_recipe_unauthorized_person(self):

                user = User.objects.create_user(username='admin2')
                user.set_password('admin')
                user.account.email = 'admin2@gmail.com'
                user.account.isAdmin = False
                user.save()		
                res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
                self.token_2 = res.data.get('token', None)

                rating = {"ratingValue":3,
                                "ratingDescription":"This is certainly food most likely"
                                 }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
                ratingID = response.data['data']

                response = self.client.delete(f'/api/recipe/{self.recipeID}/ratings/{ratingID}/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
                self.assertEqual(response.status_code,status.HTTP_403_FORBIDDEN, msg = response.data.get('message', response.data.get('detail',None)))
                        
        def test_delete_recipe_authorized_person_admin(self):

                user = User.objects.create_user(username='admin2')
                user.set_password('admin')
                user.account.email = 'admin2@gmail.com'
                user.account.isAdmin = True
                user.save()		
                res = self.client.post('/login', {'username': 'admin2', 'password': 'admin'}, format='json')
                self.token_2 = res.data.get('token', None)

                rating = {"ratingValue":3,
                                "ratingDescription":"This is certainly food most likely"
                                 }

                response = self.client.post(f'/api/recipe/{self.recipeID}/ratings/',rating, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
                ratingID = response.data['data']
        
                response = self.client.delete(f'/api/recipe/{self.recipeID}/ratings/{ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
                self.assertEqual(response.status_code,status.HTTP_204_NO_CONTENT)
        
                response = self.client.delete(f'/api/recipe/{self.recipeID}/ratings/{ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token_2}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)

        def test_get_individual_ratings_missing_recipe(self):
                recipeID = self.recipeID + 1
                response = self.client.get(f'/api/recipe/{recipeID}/ratings/{self.ratingID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
                self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND, msg = response.data.get('message', response.data.get('detail',None)))



