from django import forms

from django.contrib.postgres.forms import SimpleArrayField
from .models import Ingredient

class CreateRecipeForm(forms.Form):
	recipeAuthor = forms.CharField(max_length=100,required=True)
	nameOfRecipe = forms.CharField(max_length=100,required=True)
	instructions = forms.CharField(widget=forms.Textarea,required=True)
	recipeIngredients = forms.ModelMultipleChoiceField(queryset=Ingredient.objects.all(),required=True)
	tags = SimpleArrayField(forms.CharField(max_length=30,required=False))

class RatingForm(forms.Form):
	ratingValue = forms.IntegerField(min_value = 1, max_value = 5, required=True)
	