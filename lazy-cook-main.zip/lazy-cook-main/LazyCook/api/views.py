from django.shortcuts import render
import warnings
warnings.filterwarnings("ignore")
# Create your views here.

from rest_framework import viewsets,status
from rest_framework.response import Response
from .models import Recipe,Ingredient, RecipeRating
from .forms import CreateRecipeForm, RatingForm
from django.core.exceptions import ObjectDoesNotExist
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from account.authentication import ExpiringTokenAuthentication
#import django.contrib.postgres
import string
import requests
import simplejson as json
import base64

from django.core.paginator import Paginator
from google.oauth2 import service_account
from os.path import expanduser
from os import getenv

import google
from google.auth.transport import requests as googlerequests
from api.utils import upload_file
from PIL import Image
from io import BytesIO

class PictureInput(viewsets.ViewSet):
	authentication_classes = [ExpiringTokenAuthentication]
	permission_classes = [IsAuthenticated]

	def create(self,request):
		if not request.user.account.isAdmin:
			return Response({"message": 'Must be an admin to create a recipe'}, status=403)
		service_account_key = getenv(
			'GOOGLE_APPLICATION_CREDENTIALS',
			f'{expanduser(".")}/charged-formula-307714-b938a1d18c46.json'
		)
		# Creates a credentials object from the service account file
		credentials = service_account.Credentials.from_service_account_file(
			service_account_key, # key path
			scopes=['https://www.googleapis.com/auth/cloud-platform'] # scopes
		)
		# Prepare an authentication request
		auth_req = google.auth.transport.requests.Request()
		# Request refresh tokens
		credentials.refresh(auth_req)
		# now we can print the access token
		# print(credentials.token)
		
		if 'image' not in request.data:
			return Response({"message": 'Missing image'}, status=400)

		data = request.data.get('image').temporary_file_path()
		# image = Image.open(data)

		image_string = ""

		with Image.open(data) as im:
			buffered = BytesIO()
			im.save(buffered, format="JPEG")
			image_string = base64.b64encode(buffered.getvalue())
				
		payload = {"payload": 
				{"image": 
					{"imageBytes": image_string}
				}
			}
		headers = {
				'Content-Type': 'application/json',
				'Authorization':'Bearer '+ credentials.token
				}
		url = 'https://automl.googleapis.com/v1beta1/projects/1011318776734/locations/us-central1/models/IOD9084387170034122752:predict'
		r = requests.post(url,data=json.dumps(payload), headers=headers)
		data = r.json()
		#print(data)
		if "error" in data:
			return Response({"message": 'Please connect develop group to deploy model.'}, status=401)
		else :
			if "payload" in data:
				field_list = data["payload"]
				returnlist = []
				ingredientset = set() 
				for fields in field_list:
					if fields['displayName'] in ingredientset:
						continue
					else:
						returnlist.append(fields['displayName'])
						ingredientset.add(fields['displayName'])
				return Response({"message": 'Successful predict ingredient',"data":returnlist})
			else:
				return Response({"message": 'No ingredient predicted.Please try retake a photo or type in ingredients you have.'}, status=404)


	
class RecipeView(viewsets.ViewSet):
	#Current list of all ingredient ID's for ID creation and search purposes
	listIDs = Ingredient.objects.all().values_list('ingredientID', flat=True)

	authentication_classes = [ExpiringTokenAuthentication]
	permission_classes = [IsAuthenticated]


	#Used to return the next ID number associated with a new ingredient
	def returnIdentifierNumber(inLetter):
		highestNumber = 0
		for ids in RecipeView.listIDs:
			if inLetter == str(ids[0]):
				if  int(ids[1]) > highestNumber:
					highestNumber = int(ids[1])
		return highestNumber



	#Used to update the list of ingredient ID's after a recipe has been added or edited
	def updateListIDs():
		RecipeView.listIDs = Ingredient.objects.all().values_list('ingredientID', flat=True)

	def createIngredientList(ingredients):
		#Updates the local list of ID's for searching purposes
		RecipeView.updateListIDs()
		
		ingredientList = []
		for ingredient in ingredients:
			#Check if the ingredient has multiple words
			ingredientWordList = []
			wordPartRecognized = False
			if ' ' in ingredient:
				ingredientWordList = ingredient.split(' ')
				for ingredientPart in ingredientWordList:
					ingredientFilter = Ingredient.objects.filter(ingredientDescription__icontains=ingredientPart)
					if ingredientFilter.filter(ingredientDescription__icontains=ingredientPart).exists():
						wordPartRecognized = True
			else:
				ingredientFilter = Ingredient.objects.filter(ingredientDescription__icontains=ingredient)
				if ingredientFilter.filter(ingredientDescription__icontains=ingredient).exists():
						wordPartRecognized = True

			if not wordPartRecognized:
				IDnumber = int(RecipeView.returnIdentifierNumber(ingredient[0].upper())) + 1
				myIngredientID = ingredient[0].upper() + str(IDnumber)
				myIngredient = Ingredient.objects.create(ingredientID=myIngredientID,ingredientDescription=ingredient)
			else:
				myIngredient = Ingredient.objects.get(id=ingredientFilter[0].id)
			ingredientList.append(myIngredient)
		return ingredientList


	def list(self,request):
		#Updates the local list of ID's for searching purposes
		RecipeView.updateListIDs()

		desiredRecipe = request.query_params.get("RecipeKeywords",None)
		desiredTags = []#request.query_params.get("Tags",None)
		if request.user.account.vegetarian:
                                        desiredTags.append("vegetarian")
		if request.user.account.vegan:
                                        desiredTags.append("vegan")
		if request.user.account.lactoseIntolerance:
                                        desiredTags.append("lactose intolerance")
		if request.user.account.glutenFree:
                                        desiredTags.append("gluten free")
		desiredIngredients = request.query_params.get("Ingredients",None)
		pageNumber = request.query_params.get("Page",None)
		if not pageNumber == None:
			if not pageNumber.isnumeric():
				return Response({"message": 'Invalid Page Number',"data":[]},status=400)
			if int(pageNumber) <= 0:
				return Response({"message": 'Invalid Page Number',"data":[]},status=400)
		#Turning ingredients into list format and then creating a new list of ingredient ID's to search with
		ingredientList = []
		if desiredIngredients != None:
			ingredientList = desiredIngredients.split(',')
		i = 0
		desiredIDList = []
		for ingredient in ingredientList:
			#Trim spaces at beginning and end of string
			ingredient.lstrip()
			ingredient.rstrip()
			#First check if the ingredient entered has multiple words 
			ingredientWordList = []
			if ' ' in ingredient:
				ingredientWordList = ingredient.split(' ')
				for ingredientPart in ingredientWordList:
					ingredientFilter = Ingredient.objects.filter(ingredientDescription__icontains=ingredientPart)
					if ingredientFilter.filter(ingredientDescription__icontains=ingredientPart).exists():
						try:
							thisIngredient = Ingredient.objects.filter(ingredientDescription__icontains=ingredientPart).first()
							if thisIngredient is not None:
								thisIngredientID = thisIngredient.ingredientID
								desiredIDList.append(thisIngredientID)
						except Ingredient.DoesNotExist:
							pass #Ingredient not in recipe databse, ignore
			else:
				try:
					thisIngredient = Ingredient.objects.filter(ingredientDescription__icontains=ingredient).first()
					if thisIngredient is not None:
						thisIngredientID = thisIngredient.ingredientID
						desiredIDList.append(thisIngredientID)
				except Ingredient.DoesNotExist:
					pass

		if desiredIngredients != None:
			#NOTE: filter returns a query set, get returns a value
			#First, check if the only entered ingredient does not exist, if so, return an empty set.
			if not desiredIDList:
				return Response({"message": 'No recipes found for your ingredient',"data":[]})

			#Second, get every recipe that contains the first desiredID to filter out all other recipes
			#filteredRecipes = Recipe.objects.filter(recipeIngredients__ingredientID__icontains=desiredIDList[0])
			filteredRecipes = Recipe.objects.all()

			#Get list of unesired ID's
			undesiredIDs = []
			for ids in RecipeView.listIDs:
				if not ids in desiredIDList:
					undesiredIDs.append(ids)

			#Exlude recipes with IDs we dont have in ingredients
			for ids in undesiredIDs:
				filteredRecipes = filteredRecipes.exclude(recipeIngredients__ingredientID__icontains=ids)
				
		elif desiredRecipe != None:
			#this method will only support a single keyword, will implement more sophisticated model later
			filteredRecipes = Recipe.objects.filter(nameOfRecipe__icontains=desiredRecipe)
		else:
                                                filteredRecipes = Recipe.objects.all()
                                                
		if len(desiredTags) != 0:
                                                for tag in desiredTags:
                                                        filteredRecipes = filteredRecipes.filter(tags__icontains=tag)
		recipeList = []

		#Pagination
		p = Paginator(filteredRecipes,10)
		try:
			filteredRecipes = p.page(pageNumber).object_list
		except:
			#Page number is beyond results, return empty list. Check if page is specified first.
			if not pageNumber == None:
				filteredRecipes = []

		for recipes in filteredRecipes:
			object_name = str(recipes.recipeID)
			s3downloadurl = "https://lazy-cook-storage.s3.us-east-2.amazonaws.com/recipes/" + object_name + ".jpg"
			recipeList.append({
                                                'recipeID': recipes.recipeID,
			'recipeAuthor' : recipes.recipeAuthor,
			'dateCreatedOn' : recipes.dateCreatedOn,
			'nameOfRecipe' : recipes.nameOfRecipe,
			'instructions': recipes.instructions,
			'ingredients'  : recipes.recipeIngredientsDescription,
			'tags' : recipes.tags,
			'image': s3downloadurl
			})
		return Response({"message": 'Successful Display of recipes',"data":recipeList})


	def create(self,request):
		if not request.user.account.isAdmin:
			return Response({"message": 'Must be an admin to create a recipe'}, status=403)
		#Updates the local list of ID's for ID creation
		RecipeView.updateListIDs()

		allowedTags = ["vegetarian","vegan","lactose intolerance","gluten free"]
		form = CreateRecipeForm(request.data)
		if not form.is_valid():
			if form.errors.get('nameOfRecipe',None):
				return Response({"message": 'All recipes must have a name so it can be searched for later'}, status=400)
			elif form.errors.get('instructions', None):
				return Response({"message": 'Recipes require some instructions'}, status=400)
		
		ingredientRequest = request.data.get('recipeIngredients',None)
		if len(ingredientRequest) == 0:
			return Response({"message": 'Ingredients field can not be empty'}, status=400)
		ingredients         = []
		amountOfIngredients = []
		for ingredient in ingredientRequest:
			try:
				ingredients.append(ingredient["ingredient"])
				amountOfIngredients.append(ingredient["amount"])
			except KeyError:
				return Response({"message": 'Ingredients must have corresponding amounts'}, status=400)
		nameOfRecipe = request.data.get('nameOfRecipe',None)
		recipeAuthor = request.user.account.user
		instructions = request.data.get('instructions',None)
		tags = request.data.get('tags',None)
		if len(tags) > 4:
			return Response({"message": 'You have too many tags for this recipe, remove some'}, status=400)
		for tagCheck in tags:
			if tagCheck not in allowedTags:
				return Response({"message": 'Invalid Tag'}, status=400)
		recipeIngredientsDescription = "\n".join(map(" ".join,zip(amountOfIngredients,ingredients)))
    
		newRecipe = Recipe.objects.create(nameOfRecipe=nameOfRecipe,recipeAuthor=recipeAuthor,
					instructions=instructions,recipeIngredientsDescription = recipeIngredientsDescription,
					tags=tags)

		if 'image' in request.data:
			image = request.data.get('image').temporary_file_path()
			object_name = f"{'recipes/'}{str(newRecipe.recipeID)}{'.jpg'}"
			try:
				upload_file(image,"lazy-cook-storage",object_name)
			except:
				newRecipe.delete()
				return Response({"message": 'Recipe require valid image'}, status=400)

		#Adds ingredients based on method to stop repeating code
		newRecipe.recipeIngredients.set(RecipeView.createIngredientList(ingredients))

		return Response({"message": 'Recipe has been created',"data":newRecipe.recipeID},status=201)

	def retrieve(self,request,pk=None):
		try:
			recipeRetrieval = Recipe.objects.get(recipeID=pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)
		object_name = str(recipeRetrieval.recipeID)
		s3downloadurl = "https://lazy-cook-storage.s3.us-east-2.amazonaws.com/recipes/" + object_name + ".jpg"
		data = {
			'recipeAuthor' : recipeRetrieval.recipeAuthor,
			'dateCreatedOn' : recipeRetrieval.dateCreatedOn,
			'nameOfRecipe' : recipeRetrieval.nameOfRecipe,
			'instructions': recipeRetrieval.instructions,
			'ingredients'  : recipeRetrieval.recipeIngredientsDescription,
			'tags' : recipeRetrieval.tags,
			'image': s3downloadurl
			}
			
		return Response({"message": f'You are looking at recipe {pk}',"data":data}, status=200)


	def update(self,request,pk=None):
		#Updates the local list of ID's for searching purposes
		RecipeView.updateListIDs()
		
		allowedTags = ["vegetarian","vegan","lactose intolerance","gluten free"]
		try:
			recipeRetrieval = Recipe.objects.get(recipeID=pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)
		if not request.user.account.isAdmin:
			return Response({"message": 'Must be an admin or the author of the recipe to modify it'}, status=403)
		form = CreateRecipeForm(request.data)
		if not form.is_valid():
			if form.errors.get('nameOfRecipe',None):
				return Response({"message": 'All recipes must have a name so it can be searched for later'}, status=400)
			elif form.errors.get('instructions', None):
				return Response({"message": 'Recipes require some instructions'}, status=400)
		
		ingredientRequest = request.data.get('recipeIngredients',None)
		if len(ingredientRequest) == 0:
			return Response({"message": 'Ingredients field can not be empty'}, status=400)
		ingredients         = []
		amountOfIngredients = []
		for ingredient in ingredientRequest:
			try:
				ingredients.append(ingredient["ingredient"])
				amountOfIngredients.append(ingredient["amount"])
			except KeyError:
				return Response({"message": 'Ingredients must have corresponding amounts'}, status=400)
		nameOfRecipe = request.data.get('nameOfRecipe',None)
		instructions = request.data.get('instructions',None)
		tags = request.data.get('tags',None)
		image = request.data.get('image',None)
		for tagCheck in tags:
			if tagCheck not in allowedTags:
				return Response({"message": 'Invalid Tag'}, status=400)
		recipeIngredientsDescription = "\n".join(map(" ".join,zip(amountOfIngredients,ingredients)))

		recipeRetrieval.nameOfRecipe = nameOfRecipe
		recipeRetrieval.instructions = instructions
		recipeRetrieval.tags = tags
		recipeRetrieval.image = image
		recipeRetrieval.recipeIngredientsDescription = recipeIngredientsDescription
		#Adds ingredients based on method to stop repeating code
		recipeRetrieval.recipeIngredients.set(RecipeView.createIngredientList(ingredients))
		recipeRetrieval.save()
		return Response({"message": 'Update Successful'},status=200)

	def partial_update(self,request,pk=None):
		#Updates the local list of ID's for searching purposes
		RecipeView.updateListIDs()

		allowedTags = ["vegetarian","vegan","lactose intolerance","gluten free"]
		try:
			recipeRetrieval = Recipe.objects.get(recipeID=pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)
		if not request.user.account.isAdmin:
			return Response({"message": 'Must be an admin to access endpoint'}, status=403)
		nameOfRecipe = request.data.get('nameOfRecipe',None)
		ingredientRequest = request.data.get('recipeIngredients',None)
		instructions = request.data.get('instructions',None)
		tags = request.data.get('tags',None)
		image = request.data.get('image',None)
		if nameOfRecipe != None:
			recipeRetrieval.nameOfRecipe = nameOfRecipe
		if instructions != None:
			recipeRetrieval.instructions = instructions
		if tags != None:
			for tagCheck in tags:
				if tagCheck not in allowedTags:
					return Response({"message": 'Invalid Tag'}, status=400)
			recipeRetrieval.tags = tags
		if image != None:
			recipeRetrieval.image = image
		if ingredientRequest != None:
			ingredients         = []
			amountOfIngredients = []
			for ingredient in ingredientRequest:
				try:
					ingredients.append(ingredient["ingredient"])
					amountOfIngredients.append(ingredient["amount"])
				except KeyError:
					return Response({"message": 'Ingredients must have corresponding amounts'}, status=400)
			recipeIngredientsDescription = "\n".join(map(" ".join,zip(amountOfIngredients,ingredients)))
			recipeRetrieval.recipeIngredientsDescription = recipeIngredientsDescription
			#Adds ingredients based on method to stop repeating code
			recipeRetrieval.recipeIngredients.set(RecipeView.createIngredientList(ingredients))
		recipeRetrieval.save()
		return Response({"message": 'Update Successful'},status=200) 

	def destroy(self,request,pk=None):
		try:
			recipeRetrieval = Recipe.objects.get(recipeID=pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)
		
		if not request.user.account.isAdmin:
			return Response({"message": 'Must be an admin to access endpoint'}, status=403)

		recipeRetrieval.delete()
		return Response({"message": f'Recipe was successfully deleted'}, status=204)
	
	@action(methods=['post'], detail=True, url_path='saved-recipe', url_name='saved_recipe')
	def saved_recipe(self, request, pk=None):
		try:
			recipeRetrieval = Recipe.objects.get(recipeID=pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)
		request.user.account.savedRecipe.add(recipeRetrieval)
		return Response({"message": 'Recipe was successfully saved'}, status=201)

class RecipeRatingViewset(viewsets.ViewSet):
	authentication_classes = [ExpiringTokenAuthentication]
	permission_classes = [IsAuthenticated]

	def list(self,request,recipeID_pk=None):
		try:
			recipeRetrieval = Recipe.objects.get(recipeID=recipeID_pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)
		
		recipeRatings = RecipeRating.objects.filter(recipeReview__recipeID__exact=recipeID_pk)
		ratingsList = []
		for rating in recipeRatings:
			ratingsList.append({"ratingID":rating.ratingID,
						"ratingValue":rating.ratingValue,
					    "ratingReview":rating.ratingReview})
		return Response({"message": "Displaying Ratings for Recipe","data":ratingsList},status=200)

	def create(self,request,recipeID_pk=None):
		if not request.user.account.isAdmin:
			return Response({"message": 'Must be admin to access endpoint'}, status=403)
		form = RatingForm(request.data)
		if not form.is_valid():
			if form.errors.get('ratingValue',None):
				return Response({"message": 'Rating Value must be present and between 1 and 5'}, status=400)

		try:
			recipeRetrieval = Recipe.objects.get(recipeID=recipeID_pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)

		ratingValue = request.data.get('ratingValue',None)
		ratingReview = request.data.get('ratingDescription',"")
		ratingAuthor = request.user.account.user
		newRating = RecipeRating.objects.create(ratingValue=ratingValue,ratingReview=ratingReview,ratingAuthor=ratingAuthor,recipeReview=recipeRetrieval)
		return Response({"message": "Made Rating for Recipe","data":newRating.ratingID},status=201)

	def retrieve(self,request,recipeID_pk=None,pk=None):
		try:
			recipeRetrieval = Recipe.objects.get(recipeID=recipeID_pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)
		
		try:
			recipeRatings = RecipeRating.objects.filter(recipeReview__recipeID__exact=recipeID_pk).get(ratingID=pk)
		except RecipeRating.DoesNotExist:
			return Response({"message": 'Rating does not exist'}, status=404)

		rating = {"ratingValue":recipeRatings.ratingValue,
			  "ratingReview":recipeRatings.ratingReview}

		return Response({"message": "Displaying Ratings for Recipe","data":rating},status=200)

	def update(self,request,recipeID_pk=None,pk=None):
		form = RatingForm(request.data)
		if not form.is_valid():
			if form.errors.get('ratingValue',None):
				return Response({"message": 'Rating Value must be present and between 1 and 5'}, status=400)
		try:
			recipeRetrieval = Recipe.objects.get(recipeID=recipeID_pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)
		
		try:
			recipeRatings = RecipeRating.objects.filter(recipeReview__recipeID__exact=recipeID_pk).get(ratingID=pk)
		except RecipeRating.DoesNotExist:
			return Response({"message": 'Rating does not exist'}, status=404)

		if not request.user.account.isAdmin:
			return Response({"message": 'Must be admin to access endpoint'}, status=403)

		ratingValue = request.data.get('ratingValue',None)
		ratingReview = request.data.get('ratingDescription',None)

		recipeRatings.ratingValue = ratingValue
		recipeRatings.ratingReview = ratingReview
		recipeRatings.save()
		return Response({"message": "Rating successfully updated"},status=200)	
	
	def partial_update(self,request,recipeID_pk=None,pk=None):
		try:
			recipeRetrieval = Recipe.objects.get(recipeID=recipeID_pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)

		try:
			recipeRatings = RecipeRating.objects.filter(recipeReview__recipeID__exact=recipeID_pk).get(ratingID=pk)
		except RecipeRating.DoesNotExist:
			return Response({"message": 'Rating does not exist'}, status=404)

		if not request.user.account.isAdmin:
			return Response({"message": 'Must be admin to access endpoint'}, status=403)

		ratingValue = request.data.get('ratingValue',None)
		ratingReview = request.data.get('ratingDescription',None)
		if ratingValue != None:
			if ratingValue < 1 or ratingValue > 5:
				return Response({"message": 'Rating Value must be present and between 1 and 5'}, status=400)
			recipeRatings.ratingValue = ratingValue
		if ratingReview != None:
			recipeRatings.ratingReview = ratingReview
		recipeRatings.save()
		return Response({"message": "Rating successfully updated"},status=200)

	def delete(self,request,recipeID_pk=None,pk=None):
		try:
			recipeRetrieval = Recipe.objects.get(recipeID=recipeID_pk)
		except Recipe.DoesNotExist:
			return Response({"message": 'Recipe does not exist'}, status=404)

		try:
			recipeRatings = RecipeRating.objects.filter(recipeReview__recipeID__exact=recipeID_pk).get(ratingID=pk)
		except RecipeRating.DoesNotExist:
			return Response({"message": 'Rating does not exist'}, status=404)

		if not request.user.account.isAdmin:
			return Response({"message": 'Must be admin to access endpoint'}, status=403)

		recipeRatings.delete()

		return Response({"message": f'Rating was successfully deleted'}, status=204)

class UploadView(viewsets.ViewSet):
	authentication_classes = [ExpiringTokenAuthentication]
	permission_classes = [IsAuthenticated]

	def create(self,request):
		if not request.user.account.isAdmin:
			return Response({"message": 'Must be an admin to upload picture'}, status=403)
		if 'id' not in request.data:
			return Response({"message": 'Missing id'}, status=400)
		if 'image' in request.data:
			image = request.data.get('image').temporary_file_path()
			id = request.data.get('id')
			object_name = f"{'recipes/'}{str(id)}{'.jpg'}"
			try:
				upload_file(image,"lazy-cook-storage",object_name)
			except:
				return Response({"message": 'Recipe requires a valid image'}, status=400)
		else:
			return Response({"message": 'Missing image'}, status=400)

		return Response({"message": 'Image has been uploaded'},status=201)
