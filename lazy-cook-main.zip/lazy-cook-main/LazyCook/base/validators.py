from django.core.exceptions import ValidationError
from django.core.validators import EmailValidator

def validate_email(email):
    validator = EmailValidator()
    try:
        validator(email)
        return True
    except ValidationError:
        return False