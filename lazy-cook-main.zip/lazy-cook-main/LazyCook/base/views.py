from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from rest_framework.authtoken.models import Token
from django.contrib.auth import get_user_model
from .serializers import AccountSerializer
from account.models import Account
from .forms import SignUpForm, LoginForm

class PingView(APIView):
    def get(self, request):
        return Response({"message": "pong"})

class SignUpView(APIView):
    def post(self, request):
        f = SignUpForm(request.data)
        if not f.is_valid():
            if f.errors.get('username', None):
                return Response({"message": "missing username"}, status=400)
            if f.errors.get('password', None):
                return Response({"message": "missing password"}, status=400)
            if f.errors.get('email', None):
                return Response({"message": "invalid email"}, status=400)

        username = request.data.get('username', None)
        password = request.data.get('password', None)
        email = request.data.get('email', None)

        if User.objects.filter(username=username).exists():
            return Response({"message": "username taken"}, status=409)

        if Account.objects.filter(email=email).exists():
            return Response({"message": "email taken"}, status=409)

        if len(password) < 5:
            return Response({"message": "password too short"}, status=400)

        user = User.objects.create_user(username=username)
        user.set_password(password)
        user.account.email = email
        user.save()

        return Response({"message": "sign-up success"}, status=201)

class LoginView(APIView):
    def post(self, request):
        f = LoginForm(request.data)
        if not f.is_valid():
            if f.errors.get('username', None):
                return Response({"message": "missing username"}, status=400)
            if f.errors.get('password', None):
                return Response({"message": "missing password"}, status=400)

        username = request.data.get('username', None)
        password = request.data.get('password', None)

        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            Token.objects.filter(user=user).delete()
            token = Token.objects.create(user=user)
            return Response({"message": 'login success', "token": token.key})
        
        else:
            return Response({"message": 'invalid username and/or password'}, status=401)

# class CheckView(APIView):
#     def get(self, request):
#         User = get_user_model()
#         users = User.objects.all()
#         for user in users:
#             print(user.username)
#             print(user.password)
#             print(user.account.email)
#             print(user.account.vegan)
#         return Response({"message": "test"})

# class FormView(APIView):
#     def get(self, request):
#         f = SignUpForm(request.data)
#         if f.errors.get('username', None):
#             print('username is not valid')
#         return Response({"message": f.errors})