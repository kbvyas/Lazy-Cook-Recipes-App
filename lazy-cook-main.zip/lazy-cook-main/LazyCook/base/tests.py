from django.test import TestCase
from rest_framework.test import APITestCase
from django.contrib.auth import get_user_model
from django.contrib.auth.models import User
from rest_framework import status

class PingTest(APITestCase):
    def test_ping(self):
        response = self.client.get('/ping', format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["message"], "pong")

class SignUpTestCase(APITestCase):
    def test_sign_up_a_new_account(self):
        response = self.client.post('/signup', {"username": "user2", "password": "user2", "email": "user2@mail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        User = get_user_model()

        self.assertRaises(User.DoesNotExist, lambda : User.objects.get(username="user3"))

        try:
            username = User.objects.get(username="user2")
            self.assertEqual(username.account.email, "user2@mail.com")
        except User.DoesNotExist:
            self.fail("Should not throw DoesNotExist")
    
    def test_sign_up_a_same_account(self):
        response = self.client.post('/signup', {"username": "user2", "password": "user2", "email": "user2@mail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        response = self.client.post('/signup', {"username": "user2", "password": "user2", "email": "user2@mail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)

        response = self.client.post('/signup', {"username": "user3", "password": "user3", "email": "user2@mail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)

        User = get_user_model()

        self.assertRaises(User.DoesNotExist, lambda : User.objects.get(username="user3"))

        try:
            username = User.objects.get(username="user2")
            self.assertEqual(username.account.email, "user2@mail.com")
        except User.DoesNotExist:
            self.fail("Should not throw DoesNotExist")

    def test_sign_up_invalid_email(self):
        response = self.client.post('/signup', {"username": "user2", "password": "user2", "email": "user2"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        User = get_user_model()

        self.assertRaises(User.DoesNotExist, lambda : User.objects.get(username="user2"))

    def test_sign_up_missing_username(self):
        response = self.client.post('/signup', {"password": "user2", "email": "user2@gmail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        User = get_user_model()

        self.assertRaises(User.DoesNotExist, lambda : User.objects.get(username="user2"))

    def test_sign_up_missing_password(self):
        response = self.client.post('/signup', {"username": "user2", "email": "user2@gmail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        User = get_user_model()

        self.assertRaises(User.DoesNotExist, lambda : User.objects.get(username="user2"))

    def test_sign_up_password_too_short(self):
        response = self.client.post('/signup', {"username": "user2", "password": "u", "email": "user2@gmail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        User = get_user_model()

        self.assertRaises(User.DoesNotExist, lambda : User.objects.get(username="user2"))

class LoginTestCase(APITestCase):
    def test_login(self):
        response = self.client.post('/signup', {"username": "user2", "password": "user2", "email": "user2@mail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        
        response = self.client.post('/login', {"username": "user2", "password": "user2"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        data = response.data
        if data.get("token", None) is None:
            self.assertTrue(False, "Did not receive token after successful login")

    def test_login_missing_field(self):
        response = self.client.post('/signup', {"username": "user2", "password": "user2", "email": "user2@mail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        
        response = self.client.post('/login', {"password": "user2"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.data["message"], "missing username")

        response = self.client.post('/login', {"username": "user2"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.data["message"], "missing password")

    def test_login_multiple_times(self):
        response = self.client.post('/signup', {"username": "user2", "password": "user2", "email": "user2@mail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        
        response = self.client.post('/login', {"username": "user2", "password": "user2"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        token_1 = response.data["token"]

        response = self.client.post('/login', {"username": "user2", "password": "user2"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        token_2 = response.data["token"]

        self.assertNotEqual(token_1, token_2, "Each login should return a different token")

    def test_login_failed(self):
        response = self.client.post('/signup', {"username": "user2", "password": "user2", "email": "user2@mail.com"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        
        response = self.client.post('/login', {"username": "user2", "password": "2user"}, format='json')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

        data = response.data
        if data.get("token", None) is not None:
            self.assertTrue(False, "Should not receive token after unsuccessful login")