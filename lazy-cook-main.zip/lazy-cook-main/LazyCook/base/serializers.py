from rest_framework import serializers

class AccountSerializer(serializers.Serializer):
    email = serializers.EmailField()
    vegetarian = serializers.BooleanField()
    vegan = serializers.BooleanField()
    glutenFree = serializers.BooleanField()
    lactoseIntolerance = serializers.BooleanField()
    isAdmin = serializers.BooleanField()