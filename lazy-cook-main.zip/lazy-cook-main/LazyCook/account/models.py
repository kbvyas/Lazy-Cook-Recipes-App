from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from api.models import Recipe

class Account(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    email = models.EmailField(unique=True, default="email@email.com")
    vegetarian = models.BooleanField(default=False)
    vegan = models.BooleanField(default=False)
    glutenFree = models.BooleanField(default=False)
    lactoseIntolerance = models.BooleanField(default=False)
    isAdmin = models.BooleanField(default=False)
    savedRecipe = models.ManyToManyField(Recipe)

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Account.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.account.save()