from django.urls import include, path
from rest_framework_nested.routers import DefaultRouter, NestedDefaultRouter
from . import views
from .views import SavedRecipeViewSet

router = DefaultRouter()
router.register(r'', views.AccountViewSet, basename="account")

recipe_router = NestedDefaultRouter(router,r'',lookup='user')
recipe_router.register(r'saved-recipe',SavedRecipeViewSet,basename='saved-recipe')

urlpatterns = [
    path('', include(router.urls)),
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework')),
    path('',include(recipe_router.urls))
]