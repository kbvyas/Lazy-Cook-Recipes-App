from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from django.db import models
from rest_framework.authentication import SessionAuthentication, BasicAuthentication, TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from .authentication import ExpiringTokenAuthentication
from rest_framework.authtoken.models import Token
from .forms import AccountForm
from .models import Account, Recipe
from base.validators import validate_email

class AccountViewSet(viewsets.ViewSet):
    
    authentication_classes = [ExpiringTokenAuthentication]
    permission_classes = [IsAuthenticated]

    def list(self, request):
        if not request.user.account.isAdmin:
            return Response({"message": "request not allowed for this type of user"}, status=403)

        User = get_user_model()
        users = User.objects.all()
        data = []
        for user in users:
            data.append({
                'username': user.get_username(),
                'email': user.account.email,
                'vegetarian': user.account.vegetarian,
                'vegan': user.account.vegan,
                'glutenFree': user.account.glutenFree,
                'lactoseIntolerance': user.account.lactoseIntolerance,
                'isAdmin': user.account.isAdmin
            })
            
        return Response({"message": 'success', 'data': data})

    def create(self, request):
        if not request.user.account.isAdmin:
            return Response({"message": "request not allowed for this type of user"}, status=403)

        f = AccountForm(request.data)
        if not f.is_valid():
            if f.errors.get('username', None):
                return Response({"message": "missing username"}, status=400)
            if f.errors.get('password', None):
                return Response({"message": "missing password"}, status=400)
            if f.errors.get('email', None):
                return Response({"message": "invalid email"}, status=400)

        username = request.data.get('username', None)
        password = request.data.get('password', None)
        email = request.data.get('email', None)
        vegetarian = request.data.get('vegetarian', False)
        vegan = request.data.get('vegan', False)
        glutenFree = request.data.get('glutenFree', False)
        lactoseIntolerance = request.data.get('lactoseIntolerance', False)
        isAdmin = request.data.get('isAdmin', False)

        if User.objects.filter(username=username).exists():
            return Response({"message": "username taken"}, status=409)

        if Account.objects.filter(email=email).exists():
            return Response({"message": "email taken"}, status=409)

        if len(password) < 5:
            return Response({"message": "password too short"}, status=400)

        user = User.objects.create_user(username=username)
        user.set_password(password)
        user.account.email = email
        user.account.vegetarian = vegetarian
        user.account.vegan = vegan
        user.account.glutenFree = glutenFree
        user.account.lactoseIntolerance = lactoseIntolerance
        user.account.isAdmin = isAdmin
        user.save()

        return Response({"message": "success adding user"}, status=201)

    def retrieve(self, request, pk=None):
        if request.user.get_username() != pk and not request.user.account.isAdmin:
            return Response({"message": "request not allowed for this type of user"}, status=403)
        
        User = get_user_model()
        try:
            user = User.objects.get(username=pk)
        except User.DoesNotExist:
            return Response({"message": "user with this username does not exist"}, status=404)

        data = {
            'username': user.get_username(),
            'email': user.account.email,
            'vegetarian': user.account.vegetarian,
            'vegan': user.account.vegan,
            'glutenFree': user.account.glutenFree,
            'lactoseIntolerance': user.account.lactoseIntolerance,
            'isAdmin': user.account.isAdmin
        }

        return Response({"message": 'success', 'data': data})

    def destroy(self, request, pk=None):
        if request.user.get_username() != pk and not request.user.account.isAdmin:
            return Response({"message": "request not allowed for this type of user"}, status=403)

        User = get_user_model()
        try:
            user = User.objects.get(username=pk)
        except User.DoesNotExist:
            return Response({"message": "user with this username does not exist"}, status=404)
        
        user.delete()
        
        return Response({"message": "delete success"}, status=204)

    def update(self, request, pk=None):
        if not request.user.account.isAdmin:
            return Response({"message": "request not allowed for this type of user"}, status=403)

        f = AccountForm(request.data)
        if not f.is_valid():
            if f.errors.get('username', None):
                return Response({"message": "missing username"}, status=400)
            if f.errors.get('password', None):
                return Response({"message": "missing password"}, status=400)
            if f.errors.get('email', None):
                return Response({"message": "invalid email"}, status=400)

        username = request.data.get('username', None)
        password = request.data.get('password', None)
        email = request.data.get('email', None)
        vegetarian = request.data.get('vegetarian', False)
        vegan = request.data.get('vegan', False)
        glutenFree = request.data.get('glutenFree', False)
        lactoseIntolerance = request.data.get('lactoseIntolerance', False)
        isAdmin = request.data.get('isAdmin', False)

        User = get_user_model()
        try:
            user = User.objects.get(username=pk)
        except User.DoesNotExist:
            return Response({"message": "user with this username does not exist"}, status=404)

        if User.objects.filter(username=username).exists() and self.kwargs['pk'] != username:
            return Response({"message": "username taken"}, status=409)

        account = Account.objects.filter(email=email)
        if account.exists() and account.first().user.get_username() != self.kwargs['pk']:
            return Response({"message": "email taken"}, status=409)

        if len(password) < 5:
            return Response({"message": "password too short"}, status=400)

        user.username = username
        user.set_password(password)
        user.account.email = email
        user.account.vegetarian = vegetarian
        user.account.vegan = vegan
        user.account.glutenFree = glutenFree
        user.account.lactoseIntolerance = lactoseIntolerance
        user.account.isAdmin = isAdmin
        user.save()

        return Response({"message": "update success"}, status=200)

    def partial_update(self, request, pk=None):
        if request.user.get_username() != pk and not request.user.account.isAdmin:
            return Response({"message": "request not allowed for this type of user"}, status=403)

        username = request.data.get('username', None)
        password = request.data.get('password', None)
        email = request.data.get('email', None)
        vegetarian = request.data.get('vegetarian', None)
        vegan = request.data.get('vegan', None)
        glutenFree = request.data.get('glutenFree', None)
        lactoseIntolerance = request.data.get('lactoseIntolerance', None)
        isAdmin = request.data.get('isAdmin', None)

        User = get_user_model()
        try:
            user = User.objects.get(username=pk)
        except User.DoesNotExist:
            return Response({"message": "user with this username does not exist"}, status=404)

        if username != None and user.get_username() != username:
            return Response({"message": "username cannot be changed"}, status=409)

        if isAdmin != None and user.account.isAdmin != isAdmin:
            return Response({"message": "user type cannot be changed"}, status=409)

        if email != None:
            account = Account.objects.filter(email=email)
            
            if not validate_email(email):
                return Response({"message": "invalid email"}, status=400)
            
            if account.exists() and account.first().user.get_username() != self.kwargs['pk']:
                return Response({"message": "email taken"}, status=409)

        if password != None and len(password) < 5:
            return Response({"message": "password too short"}, status=400)

        if email != None:
            user.account.email = email
        
        if password != None:
            user.set_password(password)
        
        if vegetarian != None:
            user.account.vegetarian = vegetarian
        
        if vegan != None:
            user.account.vegan = vegan
        
        if glutenFree != None:
            user.account.glutenFree = glutenFree
        
        if lactoseIntolerance != None:
            user.account.lactoseIntolerance = lactoseIntolerance
        
        user.save()

        return Response({"message": "update success"}, status=200)

class SavedRecipeViewSet(viewsets.ViewSet):
    authentication_classes = [ExpiringTokenAuthentication]
    permission_classes = [IsAuthenticated]

    def list(self,request,user_pk=None):

        if request.user.get_username() != user_pk and not request.user.account.isAdmin:
            return Response({"message": 'request not allowed for this type of user'}, status=403)

        savedRecipes = request.user.account.savedRecipe.all()
        recipeList = []

        for recipes in savedRecipes:
            s3downloadurl = "https://lazy-cook-storage.s3.us-east-2.amazonaws.com/recipes/" + str(recipes.recipeID) + ".jpg"
            recipeList.append({
                'recipeID': recipes.recipeID,
			    'recipeAuthor' : recipes.recipeAuthor,
			    'dateCreatedOn' : recipes.dateCreatedOn,
			    'nameOfRecipe' : recipes.nameOfRecipe,
			    'instructions': recipes.instructions,
			    'ingredients'  : recipes.recipeIngredientsDescription,
			    'tags' : recipes.tags,
			    'image' : s3downloadurl,
			})
		
        return Response({"message": "Displaying Saved Recipes","data":recipeList},status=200)

    def retrieve(self,request,user_pk=None,pk=None):
        if request.user.get_username() != user_pk and not request.user.account.isAdmin:
            return Response({"message": 'request not allowed for this type of user'}, status=403)
        
        recipeRetrieval = None

        try:
            recipeRetrieval = Recipe.objects.get(recipeID=pk)
        except Recipe.DoesNotExist:
            return Response({"message": 'Recipe does not exist'}, status=404)

        savedRecipes = request.user.account.savedRecipe.filter(recipeID__exact=pk).first()
        if savedRecipes != None:
            s3downloadurl = "https://lazy-cook-storage.s3.us-east-2.amazonaws.com/recipes/" + str(savedRecipes.recipeID) + ".jpg"
            recipe = {
                'recipeID': savedRecipes.recipeID,
                'recipeAuthor' : savedRecipes.recipeAuthor,
                'dateCreatedOn' : savedRecipes.dateCreatedOn,
                'nameOfRecipe' : savedRecipes.nameOfRecipe,
                'instructions': savedRecipes.instructions,
                'ingredients'  : savedRecipes.recipeIngredientsDescription,
                'tags' : savedRecipes.tags,
                'image' : s3downloadurl,
            }
            return Response({"message": "Displaying Saved Recipe","data":recipe},status=200)

        return Response({"message": 'User has not saved this recipe'}, status=404)
    
    def delete(self,request,user_pk=None,pk=None):
        if request.user.get_username() != user_pk and not request.user.account.isAdmin:
            return Response({"message": 'request not allowed for this type of user'}, status=403)
        
        try:	
            recipeRetrieval = Recipe.objects.get(recipeID=pk)
        except Recipe.DoesNotExist:
            return Response({"message": 'Recipe does not exist'}, status=404)
        
        savedRecipes = request.user.account.savedRecipe.filter(recipeID__exact=pk).first()

        if savedRecipes != None:
            request.user.account.savedRecipe.remove(savedRecipes)
        return Response({"message": 'Saved recipe was successfully deleted'}, status=204)