from django.test import TestCase
from rest_framework.test import APITestCase
from django.contrib.auth import get_user_model
from django.contrib.auth.models import User
from rest_framework import status
from api.views import Recipe

class AccountTestCase(APITestCase):
    def setUp(self):
        user = User.objects.create_user(username='admin')
        user.set_password('admin')
        user.account.email = 'admin@gmail.com'
        user.account.isAdmin = True
        user.save()
        res = self.client.post('/login', {'username': 'admin', 'password': 'admin'}, format='json')
        self.token = res.data.get('token', None)
        self.assertIsNotNone(self.token, "Failed to setup test case")

    def test_get_account(self):
        user = User.objects.create_user(username='test_user_1')
        user.set_password('test_user_1')
        user.account.email = 'test_user_1@gmail.com'
        user.save()

        response = self.client.get('/account/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK, msg=response.data.get('message', response.data.get('detail', None)))
        
        data = response.data.get('data')
        self.assertEqual(data[0].get('email'), 'admin@gmail.com')
        self.assertEqual(data[1].get('email'), 'test_user_1@gmail.com')

    def test_get_account_non_admin(self):
        user = User.objects.create_user(username='test_user_1')
        user.set_password('test_user_1')
        user.account.email = 'test_user_1@gmail.com'
        user.save()

        res = self.client.post('/login', {'username': 'test_user_1', 'password': 'test_user_1'}, format='json')
        user_token = res.data.get('token', None)

        response = self.client.get('/account/', format='json', HTTP_AUTHORIZATION=f'Token {user_token}')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_post_account(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        body = {
            'username': username,
            'password': username,
            'email': email,
            'vegetarian': False,
            'vegan': True,
            'isAdmin': False
        }
        response = self.client.post('/account/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        
        User = get_user_model()
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            self.assertTrue(False, "Created user could not be found")

        self.assertEqual(user.account.email, email)
        self.assertEqual(user.account.vegan, True)
        self.assertEqual(user.account.vegetarian, False)
        self.assertEqual(user.account.glutenFree, False)
        self.assertEqual(user.account.lactoseIntolerance, False)

    def test_post_account_non_admin(self):
        user = User.objects.create_user(username='test_user_1')
        user.set_password('test_user_1')
        user.account.email = 'test_user_1@gmail.com'
        user.save()

        res = self.client.post('/login', {'username': 'test_user_1', 'password': 'test_user_1'}, format='json')
        user_token = res.data.get('token', None)

        username = "testuser1"
        email = 'testuser1@gmail.com'

        body = {
            'username': username,
            'password': username,
            'email': email,
            'vegetarian': False,
            'vegan': False,
            'isAdmin': False
        }

        response = self.client.post('/account/', body, format='json', HTTP_AUTHORIZATION=f'Token {user_token}')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_post_account_invalid_email(self):
        username = "testuser1"
        email = 'testuser1.com'

        body = {
            'username': username,
            'password': username,
            'email': email,
            'vegetarian': False,
            'vegan': True,
            'isAdmin': False
        }
        response = self.client.post('/account/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_post_account_missing_username(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        body = {
            'password': username,
            'email': email,
            'vegetarian': False,
            'vegan': True,
            'isAdmin': False
        }
        response = self.client.post('/account/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_post_account_missing_password(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        body = {
            'username': username,
            'email': email,
            'vegetarian': False,
            'vegan': True,
            'isAdmin': False
        }
        response = self.client.post('/account/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_post_account_invalid_password(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        body = {
            'username': username,
            'password': 'a',
            'email': email,
            'vegetarian': False,
            'vegan': True,
            'isAdmin': False
        }
        response = self.client.post('/account/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_post_account_username_exist(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        body = {
            'username': username,
            'password': username,
            'email': email,
            'vegetarian': False,
            'vegan': True,
            'isAdmin': False
        }
        
        response = self.client.post('/account/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        body["email"] = "test@gmail.com"

        response = self.client.post('/account/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)

    def test_post_account_email_exist(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        body = {
            'username': username,
            'password': username,
            'email': email,
            'vegetarian': False,
            'vegan': True,
            'isAdmin': False
        }
        
        response = self.client.post('/account/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        body["username"] = "testuser2"

        response = self.client.post('/account/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)

    def test_get_account_username(self):
        username = 'test_user_1'
        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = f'{username}@gmail.com'
        user.account.vegan = True
        user.save()

        response = self.client.get(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        data = response.data.get('data')
        self.assertEqual(data.get('email'), f'{username}@gmail.com')
        self.assertEqual(data.get('vegan'), True)

    def test_get_account_username_does_not_exist(self):
        username = 'test_user_1'
        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = f'{username}@gmail.com'
        user.account.vegan = True
        user.save()

        response = self.client.get(f'/account/{username}_fake/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_get_account_username_by_different_user(self):
        username = 'test_user_1'
        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = f'{username}@gmail.com'
        user.save()

        username_2 = 'test_user_2'
        user_2 = User.objects.create_user(username=username_2)
        user_2.set_password(username_2)
        user_2.account.email = f'{username_2}@gmail.com'
        user_2.save()

        res = self.client.post('/login', {'username': username_2, 'password': username_2}, format='json')
        user_token = res.data.get('token', None)
        response = self.client.get(f'/account/{username}_fake/', format='json', HTTP_AUTHORIZATION=f'Token {user_token}')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_put_account_username(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'username': username,
            'password': username,
            'email': f'{email}m',
            'vegetarian': True,
            'vegan': True,
            'glutenFree': True,
            'lactoseIntolerance': False
        }

        response = self.client.put(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        response = self.client.get(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        data = response.data.get('data')
        self.assertEqual(data.get('email'), f'{email}m')
        self.assertEqual(data.get('vegan'), True)
        self.assertEqual(data.get('lactoseIntolerance'), False)

    def test_put_account_username_missing_username(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'password': username,
            'email': f'{email}m',
            'vegetarian': True,
            'vegan': True,
            'glutenFree': True,
            'lactoseIntolerance': False
        }

        response = self.client.put(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        data = response.data
        self.assertEqual(data['message'], 'missing username')

    def test_put_account_username_missing_password(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'username': username,
            'email': f'{email}m',
            'vegetarian': True,
            'vegan': True,
            'glutenFree': True,
            'lactoseIntolerance': False
        }

        response = self.client.put(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        data = response.data
        self.assertEqual(data['message'], 'missing password')

    def test_put_account_username_invalid_email(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'username': username,
            'password': username,
            'email': f'{email}.m',
            'vegetarian': True,
            'vegan': True,
            'glutenFree': True,
            'lactoseIntolerance': False
        }

        response = self.client.put(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        
        data = response.data
        self.assertEqual(data['message'], 'invalid email')

    def test_put_account_username_user_already_exist(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        username2 = "testuser2"
        email2 = 'testuser2@gmail.com'

        user2 = User.objects.create_user(username=username2)
        user2.set_password(username2)
        user2.account.email = email2
        user2.save()

        body = {
            'username': username2,
            'password': username2,
            'email': f'{email}',
            'vegetarian': True,
            'vegan': True,
            'glutenFree': True,
            'lactoseIntolerance': False
        }

        response = self.client.put(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)
        
        data = response.data
        self.assertEqual(data['message'], 'username taken')

    def test_put_account_username_email_already_exist(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        username2 = "testuser2"
        email2 = 'testuser2@gmail.com'

        user2 = User.objects.create_user(username=username2)
        user2.set_password(username2)
        user2.account.email = email2
        user2.save()

        body = {
            'username': username,
            'password': username,
            'email': f'{email2}',
            'vegetarian': True,
            'vegan': True,
            'glutenFree': True,
            'lactoseIntolerance': False
        }

        response = self.client.put(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)
        
        data = response.data
        self.assertEqual(data['message'], 'email taken')

    def test_put_account_username_incomplete_field(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'username': username,
            'password': username,
            'lactoseIntolerance': False
        }

        response = self.client.put(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_put_account_not_admin(self):
        username = 'test_user_1'
        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = f'{username}@gmail.com'
        user.account.vegan = True
        user.save()

        username2 = 'test_user_2'
        user2 = User.objects.create_user(username=username2)
        user2.set_password(username2)
        user2.account.email = 'test_user_2@gmail.com'
        user2.save()

        res = self.client.post('/login', {'username': username2, 'password': username2}, format='json')
        user_token = res.data.get('token', None)

        body = {
            'username': username,
            'password': username,
            'email': f'{username}@gmail.com',
            'vegetarian': True,
            'vegan': True,
            'glutenFree': True,
            'lactoseIntolerance': False
        }

        response = self.client.put(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {user_token}')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_put_account_username_does_not_exist(self):
        username = 'test_user_1'
        body = {
            'username': username,
            'password': username,
            'email': f'{username}@gmail.com',
            'vegetarian': True,
            'vegan': True,
            'glutenFree': True,
            'lactoseIntolerance': False
        }

        response = self.client.put(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_put_account_password_too_short(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'username': username,
            'password': 's',
            'email': f'{email}m',
            'vegetarian': True,
            'vegan': True,
            'glutenFree': True,
            'lactoseIntolerance': False
        }

        response = self.client.put(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_patch_account_username(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'username': username,
            'vegetarian': True,
            'vegan': True,
        }

        response = self.client.patch(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        response = self.client.get(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        data = response.data.get('data')
        self.assertEqual(data.get('email'), email)
        self.assertEqual(data.get('vegan'), True)
        self.assertEqual(data.get('lactoseIntolerance'), False)

    def test_patch_account_rest_of_the_fields(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'
        new_pass = "password"
        new_email = 'test@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'password': new_pass,
            'email': new_email,
            'glutenFree': True,
            'lactoseIntolerance': True,
        }

        response = self.client.patch(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        response = self.client.get(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        data = response.data.get('data')
        self.assertEqual(data.get('email'), new_email)
        self.assertEqual(data.get('vegan'), False)
        self.assertEqual(data.get('lactoseIntolerance'), True)

    def test_patch_account_username_changing_username(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'username': f'{username}123',
            'vegetarian': True,
            'vegan': True,
        }

        response = self.client.patch(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)
        
        response = self.client.get(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        data = response.data.get('data')
        self.assertEqual(data.get('username'), username)
        self.assertEqual(data.get('vegetarian'), False)
        self.assertEqual(data.get('vegan'), False)

    def test_patch_account_username_changing_user_type(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'vegetarian': True,
            'vegan': True,
            'isAdmin': True
        }

        response = self.client.patch(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)
        
        response = self.client.get(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        data = response.data.get('data')
        self.assertEqual(data.get('username'), username)
        self.assertEqual(data.get('vegetarian'), False)
        self.assertEqual(data.get('vegan'), False)

    def test_patch_account_username_email_already_exist(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        username2 = "testuser2"
        email2 = 'testuser2@gmail.com'

        user2 = User.objects.create_user(username=username2)
        user2.set_password(username2)
        user2.account.email = email2
        user2.save()

        body = {
            'email': f'{email2}',
        }

        response = self.client.patch(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)
        
        data = response.data
        self.assertEqual(data['message'], 'email taken')

    def test_patch_account_not_admin(self):
        username = 'test_user_1'
        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = f'{username}@gmail.com'
        user.account.vegan = True
        user.save()

        username2 = 'test_user_2'
        user2 = User.objects.create_user(username=username2)
        user2.set_password(username2)
        user2.account.email = 'test_user_2@gmail.com'
        user2.save()

        res = self.client.post('/login', {'username': username2, 'password': username2}, format='json')
        user_token = res.data.get('token', None)

        body = {
            'email': f'{username}@gmail.com',
            'vegetarian': True,
            'vegan': True,
        }

        response = self.client.patch(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {user_token}')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_patch_account_username_does_not_exist(self):
        username = 'test_user_1'
        body = {
            'email': f'{username}@gmail.com',
            'vegan': True,
            'glutenFree': False,
        }

        response = self.client.patch(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_patch_account_invalid_email(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'email': username,
            'vegetarian': True,
            'vegan': True,
        }

        response = self.client.patch(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        
        response = self.client.get(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        data = response.data.get('data')
        self.assertEqual(data.get('email'), email)

    def test_patch_account_password_too_short(self):
        username = "testuser1"
        email = 'testuser1@gmail.com'

        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = email
        user.save()

        body = {
            'password': 's',
            'email': f'{email}m',
            'vegetarian': True,
        }

        response = self.client.patch(f'/account/{username}/', body, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_delete_account_username(self):
        username = 'test_user_1'
        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = f'{username}@gmail.com'
        user.account.vegan = True
        user.save()

        response = self.client.delete(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        
        response = self.client.get(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

        response = self.client.delete(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_delete_account_username_does_not_exist(self):
        username = 'test_user_1'
        response = self.client.delete(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_delete_account_username_add_delete_add(self):
        username = 'test_user_1'
        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = f'{username}@gmail.com'
        user.account.vegan = True
        user.save()

        response = self.client.delete(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

        username = 'test_user_1'
        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = f'{username}@gmail.com'
        user.account.vegan = True
        user.save()
                
        response = self.client.get(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_delete_account_not_admin(self):
        username = 'test_user_1'
        user = User.objects.create_user(username=username)
        user.set_password(username)
        user.account.email = f'{username}@gmail.com'
        user.account.vegan = True
        user.save()

        username2 = 'test_user_2'
        user2 = User.objects.create_user(username=username2)
        user2.set_password(username2)
        user2.account.email = 'test_user_2@gmail.com'
        user2.save()

        res = self.client.post('/login', {'username': username2, 'password': username2}, format='json')
        user_token = res.data.get('token', None)

        response = self.client.delete(f'/account/{username}/', format='json', HTTP_AUTHORIZATION=f'Token {user_token}')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        
class AccountSavedRecipeTest(APITestCase):
    def setUp(self):
        user = User.objects.create_user(username='admin1')
        user.set_password('admin')
        user.account.email = 'admin@gmail.com'
        user.account.isAdmin = True
        user.save()
        res = self.client.post(
            '/login', {'username': 'admin1', 'password': 'admin'}, format='json')
        self.token = res.data.get('token', None)
        self.assertIsNotNone(
            self.token, "Failed to setup test case")
        recipe = {"nameOfRecipe": "broccoli",
                  "recipeAuthor": "admin1",
                  "instructions": "Cook the food",
                  "recipeIngredients": [{"ingredient": "Russet Potatoes", "amount": "1lbs"},
                                        {"ingredient": "Chicken", "amount": "1lbs"}],
                  "tags": ["vegan"],
                  }
                  
        self.username = 'admin1'
        
        response = self.client.post('/api/recipe/',recipe, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))
        self.recipeID = response.data['data']

        response = self.client.post(f'/api/recipe/{self.recipeID}/saved-recipe/',format='json',HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code,status.HTTP_201_CREATED, msg = response.data.get('message', response.data.get('detail',None)))

    def test_get_all_recipes(self):
        user = User.objects.create_user(username='test2')
        user.set_password('test2')
        user.account.email = 'test2@gmail.com'
        user.account.isAdmin = False
        user.save()
        res = self.client.post(
            '/login', {'username': 'test2', 'password': 'test2'}, format='json')
        savedRecipe1 = {"nameOfRecipe": "rice",
                        "recipeAuthor": "admin1",
                        "instructions": "Cook the food",
                        "recipeIngredients": [{"ingredient": "rice", "amount": "1lbs"},
                                            {"ingredient": "butter", "amount": "1tbs"}],
                        "tags": ["vegan"],
                        }
        response = self.client.post('/api/recipe/',savedRecipe1, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.recipeID = response.data['data']
        self.client.post(f'/api/recipe/{self.recipeID}/saved-recipe/',format='json',HTTP_AUTHORIZATION=f'Token {self.token}')

        savedRecipe2 = {"nameOfRecipe": "fried rice",
                        "recipeAuthor": "admin1",
                        "instructions": "Cook the food",
                        "recipeIngredients": [{"ingredient": "rice", "amount": "1lbs"},
                                            {"ingredient": "Chicken", "amount": "1lbs"}],
                        "tags": ["vegan"],
                        }
        response = self.client.post('/api/recipe/',savedRecipe2, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.recipeID = response.data['data']
        self.client.post(f'/api/recipe/{self.recipeID}/saved-recipe/',format='json',HTTP_AUTHORIZATION=f'Token {self.token}')

        response = self.client.get(
            f'/account/{self.username}/saved-recipe/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
        self.assertEqual(3,len(response.data['data']))
    
    def test_get_invalid_recipe(self):
        savedRecipe1 = {"nameOfRecipe": "rice",
                        "recipeAuthor": "admin1",
                        "instructions": "Cook the food",
                        "recipeIngredients": [{"ingredient": "Russet Potatoes", "amount": "1lbs"},
                                            {"ingredient": "Chicken", "amount": "1lbs"}],
                        "tags": ["vegan"],
                        }
        response = self.client.get(
            f'/account/{self.username}/saved-recipe/{self.recipeID+1}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)
    
    def test_get_invalid_user(self):
        user = User.objects.create_user(username='admin2')
        user.set_password('admin2')
        user.account.email = 'admin2@gmail.com'
        user.account.isAdmin = False
        user.save()
        res = self.client.post(
            '/login', {'username': 'admin2', 'password': 'admin2'}, format='json')
        token_2 = res.data.get('token', None)
        response = self.client.get(
            f'/account/admin1/saved-recipe/{self.recipeID}/', format='json', HTTP_AUTHORIZATION=f'Token {token_2}')
        self.assertEqual(response.status_code,status.HTTP_403_FORBIDDEN)
    
    def test_get_recipe(self):
        response = self.client.get(
            f'/account/{self.username}/saved-recipe/{self.recipeID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code,status.HTTP_200_OK, msg = response.data.get('message', response.data.get('detail',None)))
    
    def test_delete_recipe_not_found(self):
        savedRecipe1 = {"nameOfRecipe": "rice",
                        "recipeAuthor": "admin1",
                        "instructions": "Cook the food",
                        "recipeIngredients": [{"ingredient": "Russet Potatoes", "amount": "1lbs"},
                                            {"ingredient": "Chicken", "amount": "1lbs"}],
                        "tags": ["vegan"],
                        }
        response = self.client.delete(
            f'/account/{self.username}/saved-recipe/', savedRecipe1, format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)
    
    def test_delete_recipe(self):
        response = self.client.delete(
            f'/account/{self.username}/saved-recipe/{self.recipeID}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code,status.HTTP_204_NO_CONTENT, msg = response.data.get('message', response.data.get('detail',None)))
    
    def test_delete_recipe_invalid_user(self):
        user = User.objects.create_user(username='admin2')
        user.set_password('admin2')
        user.account.email = 'admin2@gmail.com'
        user.account.isAdmin = False
        user.save()
        res = self.client.post(
            '/login', {'username': 'admin2', 'password': 'admin2'}, format='json')
        token_2 = res.data.get('token', None)
        response = self.client.delete(
            f'/account/admin1/saved-recipe/{self.recipeID}/', format='json', HTTP_AUTHORIZATION=f'Token {token_2}')
        self.assertEqual(response.status_code,status.HTTP_403_FORBIDDEN)
    
    def test_delete_recipe_invalid_recipe(self):
        savedRecipe1 = {"nameOfRecipe": "rice",
                        "recipeAuthor": "admin1",
                        "instructions": "Cook the food",
                        "recipeIngredients": [{"ingredient": "Russet Potatoes", "amount": "1lbs"},
                                            {"ingredient": "Chicken", "amount": "1lbs"}],
                        "tags": ["vegan"],
                        }
        response = self.client.delete(
            f'/account/{self.username}/saved-recipe/{self.recipeID+1}/', format='json', HTTP_AUTHORIZATION=f'Token {self.token}')
        self.assertEqual(response.status_code,status.HTTP_404_NOT_FOUND)

