from django import forms

class AccountForm(forms.Form):
    username = forms.CharField(max_length=150, required = True)
    password = forms.CharField(max_length=150, required = True)
    email = forms.EmailField(required = True)
    vegetarian = forms.BooleanField(required = False)
    vegan = forms.BooleanField(required = False)
    glutenFree = forms.BooleanField(required = False)
    lactoseIntolerance = forms.BooleanField(required = False)
    isAdmin = forms.BooleanField(required = False)